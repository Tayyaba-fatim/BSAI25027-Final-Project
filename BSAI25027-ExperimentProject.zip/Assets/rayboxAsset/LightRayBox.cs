using UnityEngine;
using UnityEngine.InputSystem;

public class LightRayBox : MonoBehaviour
{
    [Header("Ray Settings")]
    public bool isOn = false;
    public float rayWidth = 0.003f;   // was 0.05 - much thinner default
    public float rayLength = 20f;

    [Header("Angle Control")]
    public float rayAngle = 0f;

    private LineRenderer mainRay;
    private PrismRayReceiver lastHitPrism = null;

    void Start()
    {
        GameObject obj = new GameObject("MainRay");
        // Unparent so the box's own scale (if any) never multiplies the ray width
        obj.transform.parent = null;
        obj.transform.localScale = Vector3.one;

        mainRay = obj.AddComponent<LineRenderer>();
        mainRay.startWidth = rayWidth;
        mainRay.endWidth = rayWidth;
        mainRay.widthMultiplier = 1f;
        mainRay.numCapVertices = 2;
        mainRay.numCornerVertices = 0;

        Material mat = new Material(Shader.Find("Unlit/Color"));
        mat.color = Color.yellow;
        mainRay.material = mat;
        mainRay.positionCount = 2;
        mainRay.useWorldSpace = true;
        mainRay.enabled = false; // hidden until Space is pressed
    }

    void Update()
    {
        var kb = Keyboard.current;
        if (kb == null) return;

        if (kb.spaceKey.wasPressedThisFrame)
        {
            isOn = !isOn;
            if (!isOn)
            {
                mainRay.enabled = false;
                if (lastHitPrism != null) lastHitPrism.HideRays();
                lastHitPrism = null;
            }
        }

        if (kb.upArrowKey.isPressed) rayAngle += 1f;
        if (kb.downArrowKey.isPressed) rayAngle -= 1f;

        if (isOn)
        {
            mainRay.enabled = true;
            // Re-apply every frame so Inspector edits to rayWidth actually take effect,
            // instead of only being set once back in Start().
            mainRay.startWidth = rayWidth;
            mainRay.endWidth = rayWidth;
            ShootRay();
        }
    }

    void ShootRay()
    {
        // Ray starts from the right side of the box (front face)
        Vector3 startPos = transform.position + transform.right *0.1f;

        // Direction adjusted by the current angle
        Vector3 direction = Quaternion.Euler(0, 0, rayAngle) * transform.right;

        if (Physics.Raycast(startPos, direction, out RaycastHit hit, rayLength))
        {
            mainRay.SetPosition(0, startPos);
            mainRay.SetPosition(1, hit.point);

            PrismRayReceiver prism = hit.collider.GetComponent<PrismRayReceiver>();
            if (prism != null)
            {
                lastHitPrism = prism;
                prism.ReceiveRay(startPos, direction, hit.point, hit.normal);
                return;
            }

            if (lastHitPrism != null) lastHitPrism.HideRays();
            lastHitPrism = null;
        }
        else
        {
            mainRay.SetPosition(0, startPos);
            mainRay.SetPosition(1, startPos + direction * rayLength);
            if (lastHitPrism != null) lastHitPrism.HideRays();
            lastHitPrism = null;
        }
    }
}