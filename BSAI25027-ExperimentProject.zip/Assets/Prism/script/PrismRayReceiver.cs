using UnityEngine;

// ── Option A bridge ──────────────────────────────────────────────────────────
// Add this to the prism, then modify LightRayBox (see Step 10-A).
[RequireComponent(typeof(PrismController))]
public class PrismRayReceiver : MonoBehaviour
{
    PrismController prism;
    void Awake() => prism = GetComponent<PrismCoantroller>();
    public void ReceiveRay(Vector3 origin, Vector3 dir, Vector3 hitPoint, Vector3 entryNormal)
    {
        Debug.Log("PrismRayReceiver.ReceiveRay called!");  
        prism.ReceiveRay(origin, dir, hitPoint, entryNormal);
    }

    public void HideRays() => prism.HideRays();
}


// ── Option B – zero changes to LightRayBox ───────────────────────────────────
// Add this INSTEAD of PrismRayReceiver. Drag LightRayBox into the field.
//[RequireComponent(typeof(PrismController))]
//public class PrismAutoDetect : MonoBehaviour
//{
//    [Tooltip("Drag your LightRayBox GameObject here")]
//    public LightRayBox lightRayBox;

//    PrismController prism;
//    bool wasHit;

//    void Awake() => prism = GetComponent<PrismController>();

//    void Update()
//    {
//        if (lightRayBox == null || !lightRayBox.isOn)
//        {
//            if (wasHit) { prism.HideRays(); wasHit = false; }
//            return;
//        }

//        Vector3 start = lightRayBox.transform.position +
//                        lightRayBox.transform.right * 0.3f;
//        Vector3 dir = Quaternion.Euler(0, 0, lightRayBox.rayAngle) *
//                        lightRayBox.transform.right;

//        if (Physics.Raycast(start, dir, out RaycastHit hit, lightRayBox.rayLength)
//            && hit.collider.gameObject == gameObject)
//        {
//            wasHit = true;
//            prism.ReceiveRay(start, dir, hit.point, hit.normal);
//        }
//        else if (wasHit)
//        {
//            prism.HideRays();
//            wasHit = false;
//        }
//    }
//}