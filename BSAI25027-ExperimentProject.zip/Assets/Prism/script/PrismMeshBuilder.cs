using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

public static class PrismMeshBuilder
{
    public static Mesh BuildMesh(float apexAngleDeg = 60f,
                                 float height = 2f, float depth = 1f)
    {
        float halfApex = apexAngleDeg * 0.5f * Mathf.Deg2Rad;
        float halfBase = height * Mathf.Tan(halfApex);
        float cy = height / 3f;

        Vector3 apex = new Vector3(0f, height - cy, 0f);
        Vector3 bl = new Vector3(-halfBase, -cy, 0f);
        Vector3 br = new Vector3(halfBase, -cy, 0f);
        float hd = depth * 0.5f;

        Vector3[] verts = {
            apex + Vector3.forward * hd,  // 0 front apex
            bl   + Vector3.forward * hd,  // 1 front bottom-left
            br   + Vector3.forward * hd,  // 2 front bottom-right
            apex + Vector3.back    * hd,  // 3 back apex
            bl   + Vector3.back    * hd,  // 4 back bottom-left
            br   + Vector3.back    * hd,  // 5 back bottom-right
        };

        int[] tris = {
            0,2,1,  3,4,5,        // front + back caps
            0,1,4,  0,4,3,        // left face
            0,3,5,  0,5,2,        // right face
            1,2,5,  1,5,4,        // base
        };

        Vector2[] uvs = new Vector2[verts.Length];
        for (int i = 0; i < verts.Length; i++)
            uvs[i] = new Vector2(verts[i].x / (halfBase * 2f) + 0.5f,
                                 verts[i].y / height);

        Mesh mesh = new Mesh();
        mesh.name = "TriangularPrism";
        mesh.vertices = verts;
        mesh.triangles = tris;
        mesh.uv = uvs;
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();
        return mesh;
    }

#if UNITY_EDITOR
    [MenuItem("GameObject/3D Object/Triangular Prism", false, 10)]
    static void CreatePrism(MenuCommand cmd)
    {
        var go = new GameObject("Triangular Prism");
        go.AddComponent<MeshFilter>().sharedMesh = BuildMesh();
        go.AddComponent<MeshRenderer>();
        var mc = go.AddComponent<MeshCollider>();
        mc.sharedMesh = BuildMesh();
        mc.convex = true;
        GameObjectUtility.SetParentAndAlign(go, cmd.context as GameObject);
        Undo.RegisterCreatedObjectUndo(go, "Create Triangular Prism");
        Selection.activeObject = go;
    }
#endif
}