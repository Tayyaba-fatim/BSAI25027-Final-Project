using UnityEngine;

public struct SpectralBand
{
    public string label;
    public float wavelengthNm;
    public float refractiveIndex;
    public Color colour;

    public SpectralBand(string label, float wavelengthNm, float n, Color colour)
    {
        this.label = label;
        this.wavelengthNm = wavelengthNm;
        this.refractiveIndex = n;
        this.colour = colour;
    }
}

public class DispersionCalculator
{
    public float CauchyA;
    public float CauchyB;

    public DispersionCalculator(float baseRefractiveIndex = 1.5f)
    {
        CauchyB = 0.00420f;
        float lam = 0.550f;
        CauchyA = baseRefractiveIndex - CauchyB / (lam * lam);
    }

    public float RefractiveIndexAt(float wavelengthNm)
    {
        float lam = wavelengthNm * 0.001f;
        return CauchyA + CauchyB / (lam * lam);
    }

    // Softer, semi-transparent colors — more realistic light bands
    public SpectralBand[] GetROYGBIV()
    {
        return new SpectralBand[]
        {
            new SpectralBand("Red",    700f, RefractiveIndexAt(700f), new Color(0.95f, 0.15f, 0.10f, 0.55f)),
            new SpectralBand("Orange", 620f, RefractiveIndexAt(620f), new Color(0.95f, 0.50f, 0.05f, 0.50f)),
            new SpectralBand("Yellow", 580f, RefractiveIndexAt(580f), new Color(0.95f, 0.90f, 0.10f, 0.50f)),
            new SpectralBand("Green",  550f, RefractiveIndexAt(550f), new Color(0.10f, 0.85f, 0.20f, 0.50f)),
            new SpectralBand("Blue",   470f, RefractiveIndexAt(470f), new Color(0.05f, 0.40f, 0.90f, 0.50f)),
            new SpectralBand("Indigo", 430f, RefractiveIndexAt(430f), new Color(0.25f, 0.05f, 0.70f, 0.50f)),
            new SpectralBand("Violet", 400f, RefractiveIndexAt(400f), new Color(0.55f, 0.05f, 0.80f, 0.50f)),
        };
    }

    public SpectralBand[] GetRGB()
    {
        return new SpectralBand[]
        {
            new SpectralBand("Red",   700f, RefractiveIndexAt(700f), new Color(0.95f, 0.15f, 0.10f, 0.55f)),
            new SpectralBand("Green", 550f, RefractiveIndexAt(550f), new Color(0.10f, 0.85f, 0.20f, 0.50f)),
            new SpectralBand("Blue",  430f, RefractiveIndexAt(430f), new Color(0.05f, 0.35f, 0.90f, 0.50f)),
        };
    }

    public SpectralBand[] GetBands(int count)
    {
        return count >= 7 ? GetROYGBIV() : GetRGB();
    }
}