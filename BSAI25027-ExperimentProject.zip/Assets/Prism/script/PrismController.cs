using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(MeshCollider))]
public class PrismController : MonoBehaviour
{
    [Header("Prism Geometry")]
    public float apexAngleDegrees = 60f;

    [Header("Glass Properties")]
    public float baseRefractiveIndex = 1.5f;

    [Header("Dispersion")]
    public bool dispersionEnabled = true;
    [Range(3, 7)] public int spectralBands = 7;

    [Header("Ray Appearance")]
    public float rayWidth = 0.003f;
    [Range(1, 5)]
    public int linesPerBand = 2;
    public float inBandSpread = 0.001f;
    public float totalSpread = 0.04f;
    public float rayLength = 4f;

    [Header("Incident Ray (incoming white beam)")]
    public float incidentRayWidth = 0.004f;

    [Header("Exit Face Search")]
    [Tooltip("Fraction of the prism's smallest dimension used as the inward search offset. Auto-scales so it works near the thin apex tip too.")]
    [Range(0.001f, 0.1f)]
    public float exitSearchOffsetFraction = 0.02f;
    [Tooltip("How far to search forward for the exit face.")]
    public float exitSearchDistance = 5f;

    [Header("Debug")]
    public bool showDebugInfo = false;

    // internal
    private DispersionCalculator dispersion;
    private RayRefraction refraction;
    private List<List<LineRenderer>> spectralRays = new();
    private LineRenderer incidentLine;
    private bool receivedThisFrame;


    [Header("Live Angle Readout (read-only, auto-updated)")]
    [Tooltip("Angle between incident ray and the normal at the entry point.")]
    public float angleOfIncidence = 0f;
    [Tooltip("Angle between incident ray direction and emergent ray direction (using the middle/green band as the representative emergent ray).")]
    public float angleOfDeviation = 0f;
    [Tooltip("True once a ray has actually been received and angles are valid.")]
    public bool hasValidReading = false;

    void Awake()
    {
        dispersion = new DispersionCalculator(baseRefractiveIndex);
        refraction = new RayRefraction();
        BuildLineRenderers();
        HideRays();
    }

    void LateUpdate()
    {
        if (!receivedThisFrame) HideRays();
        receivedThisFrame = false;
    }

    void Update()
    {
        var kb = UnityEngine.InputSystem.Keyboard.current;
        if (kb == null) return;
        if (kb.leftArrowKey.isPressed) transform.Rotate(0, 0, 1f);
        if (kb.rightArrowKey.isPressed) transform.Rotate(0, 0, -1f);
    }

    public void ReceiveRay(Vector3 origin, Vector3 dir,
                           Vector3 hitPoint, Vector3 entryNormal)
    {
        receivedThisFrame = true;
        dir = dir.normalized;

        if (showDebugInfo)
        {
            Debug.Log($"[Prism] ENTRY hitPoint={hitPoint} entryNormal={entryNormal} incomingDir={dir}");
            MeshCollider mc = GetComponent<MeshCollider>();
            if (mc != null)
                Debug.Log($"[Prism] COLLIDER BOUNDS world center={mc.bounds.center} size={mc.bounds.size} min={mc.bounds.min} max={mc.bounds.max}");
        }

        SpectralBand[] bands = dispersionEnabled
            ? dispersion.GetBands(spectralBands)
            : new[] { new SpectralBand("White", 550f, baseRefractiveIndex, Color.white) };

        foreach (var bandLines in spectralRays)
            foreach (var lr in bandLines)
                lr.enabled = false;

        for (int i = 0; i < bands.Length; i++)
        {
            var band = bands[i];

            refraction.Refract(dir, entryNormal, 1.0f, band.refractiveIndex,
                               out Vector3 insideDir);

            bool foundExit = FindExitFace(hitPoint, insideDir, entryNormal, out RaycastHit exitHit);

            if (showDebugInfo)
                Debug.Log($"[Prism] {band.label}: insideDir={insideDir} foundExit={foundExit} exitPoint={(foundExit ? exitHit.point.ToString() : "N/A")} exitNormal={(foundExit ? exitHit.normal.ToString() : "N/A")}");

            if (!foundExit)
            {
                MeshCollider mcFallback = GetComponent<MeshCollider>();
                float fallbackDist = 0.05f;
                if (mcFallback != null)
                {
                    Vector3 s = mcFallback.bounds.size;
                    fallbackDist = Mathf.Min(s.x, Mathf.Min(s.y, s.z)) * 0.5f;
                }
                exitHit.point = hitPoint + insideDir * fallbackDist;
                exitHit.normal = -Vector3.forward;
            }

            bool exitOk = refraction.Refract(
                insideDir, exitHit.normal, band.refractiveIndex, 1.0f,
                out Vector3 outsideDir);

            Vector3 exitDir = exitOk
                ? outsideDir
                : Vector3.Reflect(insideDir, exitHit.normal);

            // --- Angle readout: use the middle band as the representative emergent ray ---
            if (bands.Length > 0 && i == bands.Length / 2)
            {
                angleOfIncidence = Vector3.Angle(-dir, entryNormal);
                angleOfDeviation = Vector3.Angle(dir, exitDir);
                hasValidReading = true;
            }

            Vector3 sideDir = Vector3.Cross(exitDir, Vector3.up).normalized;
            float bandT = bands.Length > 1
                                  ? (i / (float)(bands.Length - 1) - 0.5f)
                                  : 0f;
            Vector3 bandCenter = sideDir * bandT * totalSpread;

            var bandLines = spectralRays[i];
            for (int j = 0; j < linesPerBand; j++)
            {
                float lineT = linesPerBand > 1
                                     ? (j / (float)(linesPerBand - 1) - 0.5f)
                                     : 0f;
                Vector3 lineOffset = sideDir * lineT * inBandSpread;

                Color c = band.colour;
                c.a = Mathf.Lerp(0.35f, 0.6f, 1f - Mathf.Abs(lineT));

                var lr = bandLines[j];
                lr.enabled = true;
                lr.startColor = c;
                lr.endColor = new Color(c.r, c.g, c.b, 0.1f);
                lr.material.color = c;
                lr.positionCount = 3;

                lr.startWidth = rayWidth;
                lr.endWidth = rayWidth * 0.5f;

                Vector3 offset = bandCenter + lineOffset;
                Vector3 p0 = hitPoint;
                Vector3 p1 = exitHit.point + offset;
                Vector3 p2 = p1 + exitDir * rayLength;

                lr.SetPosition(0, p0);
                lr.SetPosition(1, p1);
                lr.SetPosition(2, p2);
            }
        }

        incidentLine.enabled = true;
        incidentLine.startWidth = incidentRayWidth;
        incidentLine.endWidth = incidentRayWidth;
        incidentLine.SetPosition(0, origin);
        incidentLine.SetPosition(1, hitPoint);
    }

    public void HideRays()
    {
        foreach (var bandLines in spectralRays)
            foreach (var lr in bandLines)
                lr.enabled = false;
        if (incidentLine != null) incidentLine.enabled = false;
    }

    bool FindExitFace(Vector3 from, Vector3 dir, Vector3 entryNormal, out RaycastHit hit)
    {
        MeshCollider mc = GetComponent<MeshCollider>();
        float smallestDimension = 0.2f; // fallback if bounds unavailable
        if (mc != null)
        {
            Vector3 size = mc.bounds.size;
            smallestDimension = Mathf.Min(size.x, Mathf.Min(size.y, size.z));
        }

        // Try a few shrinking offsets - near the thin apex tip, even a small
        // fixed offset can overshoot, so if the first attempt finds nothing,
        // retry with a smaller step before giving up.
        float[] attemptFractions = { exitSearchOffsetFraction, exitSearchOffsetFraction * 0.3f, exitSearchOffsetFraction * 0.1f };

        foreach (float fraction in attemptFractions)
        {
            float offset = smallestDimension * fraction;
            Vector3 origin = from
                            - entryNormal.normalized * offset
                            + dir.normalized * (offset * 0.1f);

            if (showDebugInfo)
                Debug.Log($"[Prism] FindExitFace try offset={offset:F5} (fraction={fraction:F4}) origin={origin} dir={dir}");

            var allHits = Physics.RaycastAll(origin, dir, exitSearchDistance);

            if (showDebugInfo)
                Debug.Log($"[Prism] FindExitFace found {allHits.Length} raw hits");

            foreach (var h in allHits)
            {
                bool isThisObject = h.collider.gameObject == gameObject;
                float dot = Vector3.Dot(dir, h.normal);

                if (showDebugInfo)
                    Debug.Log($"[Prism]   -> hit {h.collider.gameObject.name} at {h.point}, normal={h.normal}, dot={dot:F3}, isThisObject={isThisObject}");

                if (isThisObject && dot > 0)
                {
                    hit = h;
                    return true;
                }
            }
        }

        hit = default;
        return false;
    }

    void BuildLineRenderers()
    {
        for (int i = 0; i < 7; i++)
        {
            var bandList = new List<LineRenderer>();
            for (int j = 0; j < linesPerBand; j++)
            {
                var go = new GameObject($"Ray_Band{i}_Line{j}");
                go.transform.parent = null;
                go.transform.localScale = Vector3.one;
                var lr = go.AddComponent<LineRenderer>();
                lr.positionCount = 3;
                lr.useWorldSpace = true;
                lr.startWidth = rayWidth;
                lr.endWidth = rayWidth * 0.5f;

                lr.widthMultiplier = 1f;
                lr.numCapVertices = 2;
                lr.numCornerVertices = 0;

                lr.material = new Material(Shader.Find("Sprites/Default"));
                lr.enabled = false;
                bandList.Add(lr);
            }
            spectralRays.Add(bandList);
        }

        var ig = new GameObject("IncidentLine");
        ig.transform.parent = null;
        ig.transform.localScale = Vector3.one;
        incidentLine = ig.AddComponent<LineRenderer>();
        incidentLine.positionCount = 2;
        incidentLine.useWorldSpace = true;
        incidentLine.startWidth = incidentRayWidth;
        incidentLine.endWidth = incidentRayWidth;
        incidentLine.widthMultiplier = 1f;
        incidentLine.numCapVertices = 2;
        incidentLine.numCornerVertices = 0;
        var m = new Material(Shader.Find("Sprites/Default"));
        m.color = Color.white;
        incidentLine.material = m;
        incidentLine.enabled = false;
    }
}