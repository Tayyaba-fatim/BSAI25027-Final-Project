using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Controls the slide-out tray of module icons.
/// Attach to a UI Panel GameObject (the tray itself).
///
/// This version forces the panel CLOSED as early and as often as possible
/// (Awake + Start) so it can never be left open by accident, regardless of
/// whatever checkbox state it was saved with in the Editor.
/// </summary>
public class ModuleTrayUI : MonoBehaviour
{
    [Header("Setup")]
    [SerializeField] private ModuleDatabase database;
    [SerializeField] private Button toggleButton;
    [SerializeField] private GameObject trayPanel;
    [SerializeField] private Transform buttonContainer;
    [SerializeField] private Button moduleButtonPrefab;

    [Header("Spawning")]
    [SerializeField] private ModuleSpawner spawner;

    private bool isOpen = false;

    private void Awake()
    {
        // Force closed immediately, before anything else runs.
        ForceClose();
    }

    private void Start()
    {
        if (trayPanel == null)
        {
            Debug.LogError("[ModuleTrayUI] 'Tray Panel' is not assigned in the Inspector!");
            return;
        }
        if (toggleButton == null)
        {
            Debug.LogError("[ModuleTrayUI] 'Toggle Button' is not assigned in the Inspector!");
            return;
        }
        if (database == null)
        {
            Debug.LogError("[ModuleTrayUI] 'Database' is not assigned in the Inspector!");
        }
        if (moduleButtonPrefab == null)
        {
            Debug.LogError("[ModuleTrayUI] 'Module Button Prefab' is not assigned in the Inspector!");
        }

        ForceClose();
        toggleButton.onClick.AddListener(ToggleTray);

        if (database != null && moduleButtonPrefab != null)
        {
            BuildButtons();
        }
    }

    private void ForceClose()
    {
        isOpen = false;
        if (trayPanel != null)
        {
            trayPanel.SetActive(false);
        }
    }

    private void ToggleTray()
    {
        isOpen = !isOpen;
        trayPanel.SetActive(isOpen);
        Debug.Log("[ModuleTrayUI] Tray toggled. isOpen = " + isOpen);
    }

    private void BuildButtons()
    {
        foreach (Transform child in buttonContainer)
        {
            Destroy(child.gameObject);
        }

        foreach (ExperimentModule module in database.modules)
        {
            if (module == null) continue;

            Button btn = Instantiate(moduleButtonPrefab, buttonContainer);
            if (module.icon != null)
            {
                btn.image.sprite = module.icon;
            }

            Text label = btn.GetComponentInChildren<Text>();
            if (label != null) label.text = module.moduleName;

            ExperimentModule capturedModule = module;
            btn.onClick.AddListener(() =>
            {
                if (spawner != null)
                {
                    spawner.SpawnModule(capturedModule);
                }
                else
                {
                    Debug.LogError("[ModuleTrayUI] 'Spawner' is not assigned - cannot spawn module.");
                }
                ForceClose();
            });
        }
    }
}