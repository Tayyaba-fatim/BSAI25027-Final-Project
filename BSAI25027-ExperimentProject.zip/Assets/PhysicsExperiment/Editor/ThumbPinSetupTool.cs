using UnityEngine;
using UnityEditor;

/// <summary>
/// Editor tool — creates the ThumbPin prefab automatically.
/// Run once: Tools > Physics Experiment > Build ThumbPin Prefab
/// </summary>
public class ThumbPinSetupTool : Editor
{
    [MenuItem("Tools/Physics Experiment/Build ThumbPin Prefab")]
    public static void BuildThumbPinPrefab()
    {
        string savePath = "Assets/PhysicsExperiment/Prefabs/ThumbPin.prefab";

        // ── Root object ───────────────────────────────────────────────────────
        GameObject root = new GameObject("ThumbPin");

        // ── Pin Needle (thin cylinder pointing up) ────────────────────────────
        GameObject needle = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        needle.name = "Needle";
        needle.transform.SetParent(root.transform);
        needle.transform.localPosition = new Vector3(0f, 0.015f, 0f); // slightly above table
        needle.transform.localScale = new Vector3(0.004f, 0.02f, 0.004f);

        // Grey needle material
        Material needleMat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        if (needleMat.shader.name == "Hidden/InternalErrorShader")
            needleMat = new Material(Shader.Find("Standard"));
        needleMat.color = new Color(0.7f, 0.7f, 0.7f);
        needle.GetComponent<Renderer>().material = needleMat;

        // Remove collider from needle (only root needs collider)
        DestroyImmediate(needle.GetComponent<Collider>());

        // ── Pin Head (small colored sphere on top) ────────────────────────────
        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.name = "PinHead";
        head.transform.SetParent(root.transform);
        head.transform.localPosition = new Vector3(0f, 0.038f, 0f);
        head.transform.localScale = new Vector3(0.012f, 0.012f, 0.012f);

        // Red head material
        Material headMat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        if (headMat.shader.name == "Hidden/InternalErrorShader")
            headMat = new Material(Shader.Find("Standard"));
        headMat.color = Color.red;
        head.GetComponent<Renderer>().material = headMat;

        // Remove collider from head
        DestroyImmediate(head.GetComponent<Collider>());

        // ── Root collider (small capsule at base for click detection) ─────────
        CapsuleCollider col = root.AddComponent<CapsuleCollider>();
        col.center = new Vector3(0f, 0.02f, 0f);
        col.radius = 0.01f;
        col.height = 0.04f;

        // ── Scripts ───────────────────────────────────────────────────────────
        ThumbPin thumbPin = root.AddComponent<ThumbPin>();

        // Assign pin head renderer
        thumbPin.pinHeadRenderer = head.GetComponent<Renderer>();

        DraggableObject draggable = root.AddComponent<DraggableObject>();
        // Note: TableLayerMask must be set manually in Inspector after prefab creation

        // ── Save as prefab ────────────────────────────────────────────────────
        string folder = "Assets/PhysicsExperiment/Prefabs";
        if (!AssetDatabase.IsValidFolder(folder))
            AssetDatabase.CreateFolder("Assets/PhysicsExperiment", "Prefabs");

        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(root, savePath);
        DestroyImmediate(root);

        if (prefab != null)
            EditorUtility.DisplayDialog("Success", "ThumbPin.prefab created at:\n" + savePath, "OK");
        else
            EditorUtility.DisplayDialog("Error", "Failed to save prefab. Check the path.", "OK");

        AssetDatabase.Refresh();
    }
}
