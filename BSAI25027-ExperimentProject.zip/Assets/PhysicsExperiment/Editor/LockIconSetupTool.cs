using UnityEngine;
using UnityEditor;
using System.IO;

/// <summary>
/// One-click tool: builds a simple LockIcon prefab (a small flat quad with
/// a generated lock-shape texture) and saves it to
/// Assets/PhysicsExperiment/Modules/LockIcon.prefab
///
/// Run via: Tools > Physics Experiment > Build Lock Icon Prefab
/// </summary>
public static class LockIconSetupTool
{
    private const string ModulesFolder = "Assets/PhysicsExperiment/Modules";
    private const string PrefabPath = ModulesFolder + "/LockIcon.prefab";

    [MenuItem("Tools/Physics Experiment/Build Lock Icon Prefab")]
    public static void BuildLockIcon()
    {
        if (!AssetDatabase.IsValidFolder(ModulesFolder))
        {
            Directory.CreateDirectory(ModulesFolder);
            AssetDatabase.Refresh();
        }

        // Build a small quad as the icon body
        GameObject icon = GameObject.CreatePrimitive(PrimitiveType.Quad);
        icon.name = "LockIcon";
        icon.transform.localScale = new Vector3(0.04f, 0.04f, 0.04f);
        icon.transform.localRotation = Quaternion.Euler(90f, 0f, 0f); // lie flat, facing up

        // Remove the collider that CreatePrimitive adds by default and
        // replace with a simple BoxCollider sized for easy clicking
        Object.DestroyImmediate(icon.GetComponent<MeshCollider>());
        BoxCollider box = icon.AddComponent<BoxCollider>();
        box.size = new Vector3(1f, 1f, 0.1f);
        box.isTrigger = true;

        // Generate a simple red padlock-shaped texture procedurally
        Texture2D tex = GenerateLockTexture();
        Material mat = new Material(Shader.Find("Unlit/Transparent"));
        mat.mainTexture = tex;

        Renderer rend = icon.GetComponent<Renderer>();
        rend.material = mat;
        rend.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;

        icon.AddComponent<LockIconButton>();

        // Save texture + material as sub-assets, then save prefab
        if (!AssetDatabase.IsValidFolder(ModulesFolder + "/Generated"))
            AssetDatabase.CreateFolder(ModulesFolder, "Generated");

        AssetDatabase.CreateAsset(tex, ModulesFolder + "/Generated/LockIconTexture.asset");
        AssetDatabase.CreateAsset(mat, ModulesFolder + "/Generated/LockIconMaterial.asset");

        PrefabUtility.SaveAsPrefabAsset(icon, PrefabPath);
        Object.DestroyImmediate(icon);

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        EditorUtility.DisplayDialog(
            "Lock Icon Created",
            "Created LockIcon.prefab at:\n" + PrefabPath +
            "\n\nNext: open your PaperSheet prefab, find the 'Lock Icon Prefab' field on its PaperSheet component, and drag this prefab into it.",
            "Got it"
        );

        EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath));
    }

    private static Texture2D GenerateLockTexture()
    {
        int size = 64;
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        Color clear = new Color(0, 0, 0, 0);
        Color lockColor = new Color(0.85f, 0.1f, 0.1f, 1f);

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                bool isLockShape = IsInsidePadlockShape(x, y, size);
                tex.SetPixel(x, y, isLockShape ? lockColor : clear);
            }
        }
        tex.Apply();
        return tex;
    }

    // Very simple padlock silhouette: a rectangle body + a ring (arc) on top
    private static bool IsInsidePadlockShape(int x, int y, int size)
    {
        float u = x / (float)size;
        float v = y / (float)size;

        // Body: rectangle roughly in the lower 55%
        bool inBody = u > 0.22f && u < 0.78f && v > 0.05f && v < 0.55f;

        // Shackle: ring shape in the upper half
        float cx = 0.5f, cy = 0.62f;
        float dx = u - cx, dy = v - cy;
        float dist = Mathf.Sqrt(dx * dx + dy * dy);
        bool inRing = dist < 0.26f && dist > 0.15f && v > 0.40f;

        return inBody || inRing;
    }
}
