#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Events;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

/// <summary>
/// One-click setup for the Top View / Normal View camera buttons.
/// Usage: Tools > Physics Experiment > Build Top View Buttons
///
/// Creates two buttons (top-right corner, away from the existing Modules
/// button) and a TopViewCameraController, wired together automatically.
/// You still need to manually set "Table Center" on the controller to an
/// empty Transform positioned at your table's center (instructions in the
/// confirmation popup).
/// </summary>
public static class TopViewButtonSetupTool
{
    private static readonly Color ButtonColor = new Color(0.2f, 0.5f, 0.9f, 1f);

    [MenuItem("Tools/Physics Experiment/Build Top View Buttons")]
    public static void BuildButtons()
    {
        Canvas canvas = Object.FindFirstObjectByType<Canvas>();
        if (canvas == null)
        {
            EditorUtility.DisplayDialog("No Canvas Found",
                "Please run 'Build Module Tray UI' first (or create a Canvas) before adding Top View buttons.",
                "OK");
            return;
        }

        // Remove any previous instance to avoid duplicates on re-run
        TopViewCameraController existingCam = Object.FindFirstObjectByType<TopViewCameraController>();
        if (existingCam != null)
        {
            Object.DestroyImmediate(existingCam.gameObject);
        }
        GameObject existingTopBtn = GameObject.Find("TopViewButton");
        if (existingTopBtn != null) Object.DestroyImmediate(existingTopBtn);
        GameObject existingNormalBtn = GameObject.Find("NormalViewButton");
        if (existingNormalBtn != null) Object.DestroyImmediate(existingNormalBtn);
        GameObject existingTableCenter = GameObject.Find("TableCenterPoint");
        if (existingTableCenter != null) Object.DestroyImmediate(existingTableCenter);

        // --- Table center reference point ---
        GameObject tableCenterGO = new GameObject("TableCenterPoint");
        GameObject tableObj = GameObject.Find("Table");
        if (tableObj != null)
        {
            Bounds bounds = CalculateBounds(tableObj);
            tableCenterGO.transform.position = new Vector3(bounds.center.x, bounds.max.y, bounds.center.z);
        }
        else
        {
            tableCenterGO.transform.position = new Vector3(0f, 0.75f, 0f);
        }

        // --- Camera controller ---
        GameObject controllerGO = new GameObject("TopViewCameraController", typeof(TopViewCameraController));
        TopViewCameraController controller = controllerGO.GetComponent<TopViewCameraController>();
        SerializedObject controllerSO = new SerializedObject(controller);
        controllerSO.FindProperty("targetCamera").objectReferenceValue = Camera.main;
        controllerSO.FindProperty("tableCenter").objectReferenceValue = tableCenterGO.transform;
        controllerSO.ApplyModifiedProperties();

        // --- Top View button (top-right) ---
        GameObject topBtnGO = CreateButton("TopViewButton", "Top View", canvas.transform,
            new Vector2(1, 1), new Vector2(1, 1), new Vector2(-160, -24));
        Button topBtn = topBtnGO.GetComponent<Button>();
        UnityEventTools.AddPersistentListener(topBtn.onClick, controller.SwitchToTopView);

        // --- Normal View button (top-right, next to Top View) ---
        GameObject normalBtnGO = CreateButton("NormalViewButton", "Normal View", canvas.transform,
            new Vector2(1, 1), new Vector2(1, 1), new Vector2(-24, -24));
        Button normalBtn = normalBtnGO.GetComponent<Button>();
        UnityEventTools.AddPersistentListener(normalBtn.onClick, controller.SwitchToNormalView);

        Selection.activeGameObject = controllerGO;

        EditorUtility.DisplayDialog(
            "Top View Buttons Created",
            "Created:\n" +
            "- 'Top View' and 'Normal View' buttons (top-right corner)\n" +
            "- TopViewCameraController\n" +
            "- TableCenterPoint (auto-positioned above your Table object if found)\n\n" +
            "IMPORTANT: select 'TableCenterPoint' in the Hierarchy and confirm its position " +
            "sits exactly at the center of your table's surface. Adjust manually if it looks off.\n\n" +
            "Press Play and click 'Top View' / 'Normal View' to test the transition.",
            "Got it"
        );
    }

    private static GameObject CreateButton(string name, string label, Transform parent,
        Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPos)
    {
        GameObject btnGO = new GameObject(name, typeof(Image), typeof(Button));
        btnGO.transform.SetParent(parent, false);

        RectTransform rect = btnGO.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.pivot = new Vector2(1, 1);
        rect.anchoredPosition = anchoredPos;
        rect.sizeDelta = new Vector2(130, 48);

        Image img = btnGO.GetComponent<Image>();
        img.color = ButtonColor;

        GameObject labelGO = new GameObject("Label", typeof(Text));
        labelGO.transform.SetParent(btnGO.transform, false);
        Text text = labelGO.GetComponent<Text>();
        text.text = label;
        text.alignment = TextAnchor.MiddleCenter;
        text.color = Color.white;
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.fontSize = 16;
        RectTransform labelRect = labelGO.GetComponent<RectTransform>();
        labelRect.anchorMin = Vector2.zero;
        labelRect.anchorMax = Vector2.one;
        labelRect.offsetMin = Vector2.zero;
        labelRect.offsetMax = Vector2.zero;

        return btnGO;
    }

    private static Bounds CalculateBounds(GameObject go)
    {
        Renderer[] renderers = go.GetComponentsInChildren<Renderer>();
        if (renderers.Length == 0)
        {
            return new Bounds(go.transform.position, Vector3.one);
        }
        Bounds bounds = renderers[0].bounds;
        for (int i = 1; i < renderers.Length; i++)
        {
            bounds.Encapsulate(renderers[i].bounds);
        }
        return bounds;
    }
}
#endif
