#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using System.IO;

/// <summary>
/// One-click tool to create the ModuleDatabase asset plus an ExperimentModule
/// asset for Prism and Raybox. It searches your project for prefabs matching
/// those names so you don't have to drag them in manually.
///
/// Usage: Tools > Physics Experiment > Build Prism + Raybox Modules
///
/// If a prefab isn't found automatically, the created module asset is left
/// with an empty "World Prefab" field for you to drag in by hand.
/// </summary>
public static class ModuleAssetSetupTool
{
    private const string ModulesFolder = "Assets/PhysicsExperiment/Modules";

    [MenuItem("Tools/Physics Experiment/Build Prism + Raybox Modules")]
    public static void BuildModules()
    {
        EnsureFolder("Assets/PhysicsExperiment");
        EnsureFolder(ModulesFolder);

        ExperimentModule prismModule = CreateOrLoadModule("Prism", "Prism");
        ExperimentModule rayboxModule = CreateOrLoadModule("Raybox", "raybox");

        // --- Build / update the database ---
        string dbPath = ModulesFolder + "/MainModuleDatabase.asset";
        ModuleDatabase database = AssetDatabase.LoadAssetAtPath<ModuleDatabase>(dbPath);
        if (database == null)
        {
            database = ScriptableObject.CreateInstance<ModuleDatabase>();
            AssetDatabase.CreateAsset(database, dbPath);
        }

        database.modules.Clear();
        if (prismModule != null) database.modules.Add(prismModule);
        if (rayboxModule != null) database.modules.Add(rayboxModule);

        EditorUtility.SetDirty(database);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        Selection.activeObject = database;

        EditorUtility.DisplayDialog(
            "Modules Created",
            "Created/updated:\n" +
            "- Modules/Prism.asset\n" +
            "- Modules/Raybox.asset\n" +
            "- Modules/MainModuleDatabase.asset\n\n" +
            "IMPORTANT: open each module asset and check the 'World Prefab' field. " +
            "If it's empty, drag in your actual Prism/Raybox prefab by hand " +
            "(the tool searches by name but can't be 100% sure it found the right one).\n\n" +
            "Then drag 'MainModuleDatabase' into the 'Database' field on ModuleTrayController.",
            "Got it"
        );
    }

    private static ExperimentModule CreateOrLoadModule(string moduleName, string searchTermForPrefab)
    {
        string assetPath = ModulesFolder + "/" + moduleName + ".asset";
        ExperimentModule module = AssetDatabase.LoadAssetAtPath<ExperimentModule>(assetPath);

        if (module == null)
        {
            module = ScriptableObject.CreateInstance<ExperimentModule>();
            module.moduleName = moduleName;
            module.spawnScale = Vector3.one;
            AssetDatabase.CreateAsset(module, assetPath);
        }

        if (module.worldPrefab == null)
        {
            GameObject foundPrefab = FindPrefabByName(searchTermForPrefab);
            if (foundPrefab != null)
            {
                module.worldPrefab = foundPrefab;
                Debug.Log($"Auto-linked '{moduleName}' module to prefab: {AssetDatabase.GetAssetPath(foundPrefab)}");
            }
            else
            {
                Debug.LogWarning($"Could not auto-find a prefab matching '{searchTermForPrefab}'. " +
                    $"Please open {assetPath} and drag the correct prefab into 'World Prefab' manually.");
            }
        }

        EditorUtility.SetDirty(module);
        return module;
    }

    private static GameObject FindPrefabByName(string nameContains)
    {
        string[] guids = AssetDatabase.FindAssets("t:Prefab");
        foreach (string guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            string fileName = Path.GetFileNameWithoutExtension(path);
            if (fileName.ToLower().Contains(nameContains.ToLower()))
            {
                return AssetDatabase.LoadAssetAtPath<GameObject>(path);
            }
        }
        return null;
    }

    private static void EnsureFolder(string path)
    {
        if (AssetDatabase.IsValidFolder(path)) return;
        string parent = Path.GetDirectoryName(path).Replace("\\", "/");
        string newFolderName = Path.GetFileName(path);
        if (!AssetDatabase.IsValidFolder(parent))
        {
            EnsureFolder(parent);
        }
        AssetDatabase.CreateFolder(parent, newFolderName);
    }
}
#endif
