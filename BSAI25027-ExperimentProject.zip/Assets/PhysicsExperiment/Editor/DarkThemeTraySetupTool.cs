#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Rebuilds a dark, modern "lab UI" themed module tray.
/// This REMOVES any existing Canvas/Spawner/ModuleTrayController objects
/// first (cleans up duplicates from earlier runs), then builds a fresh,
/// nicer-looking version.
///
/// Usage: Tools > Physics Experiment > Rebuild Dark Theme UI
/// </summary>
public static class DarkThemeTraySetupTool
{
    // ---- Color palette (dark lab theme) ----
    private static readonly Color PanelBg = new Color(0.09f, 0.10f, 0.12f, 0.92f);
    private static readonly Color ButtonBg = new Color(0.15f, 0.16f, 0.19f, 1f);
    private static readonly Color ButtonBgHover = new Color(0.20f, 0.55f, 0.85f, 1f);
    private static readonly Color AccentBlue = new Color(0.25f, 0.6f, 0.95f, 1f);
    private static readonly Color TextColor = new Color(0.9f, 0.92f, 0.95f, 1f);

    [MenuItem("Tools/Physics Experiment/Rebuild Dark Theme UI")]
    public static void RebuildUI()
    {
        CleanupOldObjects();

        // --- Canvas ---
        GameObject canvasGO = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasGO.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasGO.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);

        if (Object.FindFirstObjectByType<UnityEngine.EventSystems.EventSystem>() == null)
        {
            GameObject eventSystemGO = new GameObject("EventSystem", typeof(UnityEngine.EventSystems.EventSystem));
#if ENABLE_INPUT_SYSTEM
            eventSystemGO.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
            eventSystemGO.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
#endif
        }

        // --- Toggle Button (circular icon, top-left) ---
        GameObject toggleGO = new GameObject("ModuleToggleButton", typeof(Image), typeof(Button));
        toggleGO.transform.SetParent(canvasGO.transform, false);
        RectTransform toggleRect = toggleGO.GetComponent<RectTransform>();
        toggleRect.anchorMin = new Vector2(0, 1);
        toggleRect.anchorMax = new Vector2(0, 1);
        toggleRect.pivot = new Vector2(0, 1);
        toggleRect.anchoredPosition = new Vector2(24, -24);
        toggleRect.sizeDelta = new Vector2(64, 64);

        Image toggleImg = toggleGO.GetComponent<Image>();
        toggleImg.color = AccentBlue;
        toggleImg.sprite = CreateRoundedSquareSprite(20);
        toggleImg.type = Image.Type.Sliced;

        Button toggleButton = toggleGO.GetComponent<Button>();
        ColorBlock toggleColors = toggleButton.colors;
        toggleColors.normalColor = Color.white;
        toggleColors.highlightedColor = new Color(1f, 1f, 1f, 0.85f);
        toggleColors.pressedColor = new Color(0.8f, 0.8f, 0.8f, 1f);
        toggleButton.colors = toggleColors;

        GameObject toggleIconGO = new GameObject("Icon", typeof(Text));
        toggleIconGO.transform.SetParent(toggleGO.transform, false);
        Text toggleIcon = toggleIconGO.GetComponent<Text>();
        toggleIcon.text = "\u2697"; // flask/lab glyph
        toggleIcon.alignment = TextAnchor.MiddleCenter;
        toggleIcon.color = Color.white;
        toggleIcon.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        toggleIcon.fontSize = 28;
        StretchFull(toggleIconGO.GetComponent<RectTransform>());

        // --- Tray Panel (dark rounded background, hidden by default) ---
        GameObject trayGO = new GameObject("ModuleTrayPanel", typeof(Image), typeof(HorizontalLayoutGroup), typeof(ContentSizeFitter));
        trayGO.transform.SetParent(canvasGO.transform, false);
        RectTransform trayRect = trayGO.GetComponent<RectTransform>();
        trayRect.anchorMin = new Vector2(0, 1);
        trayRect.anchorMax = new Vector2(0, 1);
        trayRect.pivot = new Vector2(0, 1);
        trayRect.anchoredPosition = new Vector2(24, -100);
        trayRect.sizeDelta = new Vector2(200, 110);

        Image trayBg = trayGO.GetComponent<Image>();
        trayBg.color = PanelBg;
        trayBg.sprite = CreateRoundedSquareSprite(24);
        trayBg.type = Image.Type.Sliced;

        HorizontalLayoutGroup layout = trayGO.GetComponent<HorizontalLayoutGroup>();
        layout.spacing = 14;
        layout.padding = new RectOffset(16, 16, 16, 16);
        layout.childForceExpandHeight = false;
        layout.childForceExpandWidth = false;
        layout.childAlignment = TextAnchor.MiddleLeft;

        ContentSizeFitter fitter = trayGO.GetComponent<ContentSizeFitter>();
        fitter.horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        // IMPORTANT: hide the tray by default, both via SetActive AND ensure no leftover duplicates exist
        trayGO.SetActive(false);

        // --- Module Button template (saved as a prefab asset) ---
        GameObject buttonTemplate = new GameObject("ModuleButtonTemplate", typeof(Image), typeof(Button), typeof(LayoutElement));
        Image buttonBg = buttonTemplate.GetComponent<Image>();
        buttonBg.color = ButtonBg;
        buttonBg.sprite = CreateRoundedSquareSprite(16);
        buttonBg.type = Image.Type.Sliced;

        LayoutElement le = buttonTemplate.GetComponent<LayoutElement>();
        le.preferredWidth = 78;
        le.preferredHeight = 78;

        Button templateButton = buttonTemplate.GetComponent<Button>();
        ColorBlock btnColors = templateButton.colors;
        btnColors.normalColor = Color.white;
        btnColors.highlightedColor = new Color(0.85f, 0.93f, 1f, 1f);
        btnColors.pressedColor = AccentBlue;
        templateButton.colors = btnColors;

        // Icon image slot (module sprite goes here, separate from background)
        GameObject iconSlotGO = new GameObject("IconImage", typeof(Image));
        iconSlotGO.transform.SetParent(buttonTemplate.transform, false);
        Image iconSlotImg = iconSlotGO.GetComponent<Image>();
        iconSlotImg.color = Color.white;
        iconSlotImg.preserveAspect = true;
        RectTransform iconSlotRect = iconSlotGO.GetComponent<RectTransform>();
        iconSlotRect.anchorMin = new Vector2(0.15f, 0.32f);
        iconSlotRect.anchorMax = new Vector2(0.85f, 0.95f);
        iconSlotRect.offsetMin = Vector2.zero;
        iconSlotRect.offsetMax = Vector2.zero;

        // Label under the icon
        GameObject labelGO = new GameObject("Label", typeof(Text));
        labelGO.transform.SetParent(buttonTemplate.transform, false);
        Text label = labelGO.GetComponent<Text>();
        label.text = "Module";
        label.alignment = TextAnchor.LowerCenter;
        label.color = TextColor;
        label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        label.fontSize = 11;
        RectTransform labelRect = labelGO.GetComponent<RectTransform>();
        labelRect.anchorMin = new Vector2(0f, 0f);
        labelRect.anchorMax = new Vector2(1f, 0.32f);
        labelRect.offsetMin = Vector2.zero;
        labelRect.offsetMax = Vector2.zero;

        // Save as prefab asset
        string prefabFolder = "Assets/PhysicsExperiment/Prefabs";
        if (!AssetDatabase.IsValidFolder(prefabFolder))
        {
            if (!AssetDatabase.IsValidFolder("Assets/PhysicsExperiment"))
                AssetDatabase.CreateFolder("Assets", "PhysicsExperiment");
            AssetDatabase.CreateFolder("Assets/PhysicsExperiment", "Prefabs");
        }
        string buttonPrefabPath = prefabFolder + "/ModuleButton_Dark.prefab";
        GameObject buttonPrefabAsset = PrefabUtility.SaveAsPrefabAsset(buttonTemplate, buttonPrefabPath);
        Object.DestroyImmediate(buttonTemplate);

        // --- Spawner ---
        GameObject spawnerGO = new GameObject("Spawner", typeof(ModuleSpawner));
        GameObject spawnPointGO = new GameObject("SpawnPoint");
        spawnPointGO.transform.SetParent(spawnerGO.transform);
        spawnPointGO.transform.position = new Vector3(0f, 1.2f, 0f);

        ModuleSpawner spawner = spawnerGO.GetComponent<ModuleSpawner>();
        SerializedObject spawnerSO = new SerializedObject(spawner);
        spawnerSO.FindProperty("spawnPoint").objectReferenceValue = spawnPointGO.transform;
        spawnerSO.FindProperty("draggableLayerName").stringValue = "Draggable";
        spawnerSO.ApplyModifiedProperties();

        // --- Controller ---
        GameObject controllerGO = new GameObject("ModuleTrayController", typeof(ModuleTrayUI));
        ModuleTrayUI trayUI = controllerGO.GetComponent<ModuleTrayUI>();
        SerializedObject trayUISO = new SerializedObject(trayUI);
        trayUISO.FindProperty("toggleButton").objectReferenceValue = toggleButton;
        trayUISO.FindProperty("trayPanel").objectReferenceValue = trayGO;
        trayUISO.FindProperty("buttonContainer").objectReferenceValue = trayGO.transform;
        trayUISO.FindProperty("moduleButtonPrefab").objectReferenceValue = buttonPrefabAsset.GetComponent<Button>();
        trayUISO.FindProperty("spawner").objectReferenceValue = spawner;

        ModuleDatabase existingDatabase = AssetDatabase.LoadAssetAtPath<ModuleDatabase>(
            "Assets/PhysicsExperiment/Modules/MainModuleDatabase.asset");
        if (existingDatabase != null)
        {
            trayUISO.FindProperty("database").objectReferenceValue = existingDatabase;
        }
        trayUISO.ApplyModifiedProperties();

        Selection.activeGameObject = controllerGO;

        EditorUtility.DisplayDialog(
            "Dark Theme UI Built",
            "Old Canvas/Spawner/ModuleTrayController objects were removed and replaced.\n\n" +
            "The tray panel is now hidden by default and only opens when you click the lab icon (top-left).\n\n" +
            "If 'Database' wasn't auto-linked, drag MainModuleDatabase onto ModuleTrayController.",
            "Got it"
        );
    }

    private static void CleanupOldObjects()
    {
        string[] namesToRemove = { "Canvas", "Spawner", "ModuleTrayController", "EventSystem" };
        foreach (string name in namesToRemove)
        {
            GameObject[] all = Object.FindObjectsByType<GameObject>(FindObjectsSortMode.None);
            foreach (GameObject go in all)
            {
                if (go.name == name && go.transform.parent == null)
                {
                    Object.DestroyImmediate(go);
                }
            }
        }
    }

    private static void StretchFull(RectTransform rt)
    {
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
    }

    /// <summary>
    /// Generates a simple rounded-rectangle sprite at runtime in the Editor
    /// so buttons/panels don't look like flat default Unity rectangles.
    /// </summary>
    private static Sprite CreateRoundedSquareSprite(int cornerRadius)
    {
        int size = 128;
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        Color clear = new Color(1, 1, 1, 0);
        Color white = Color.white;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                bool inside = IsInsideRoundedRect(x, y, size, size, cornerRadius);
                tex.SetPixel(x, y, inside ? white : clear);
            }
        }
        tex.Apply();
        tex.filterMode = FilterMode.Bilinear;

        Sprite sprite = Sprite.Create(
            tex,
            new Rect(0, 0, size, size),
            new Vector2(0.5f, 0.5f),
            100f,
            0,
            SpriteMeshType.FullRect,
            new Vector4(cornerRadius, cornerRadius, cornerRadius, cornerRadius)
        );
        return sprite;
    }

    private static bool IsInsideRoundedRect(int x, int y, int width, int height, int radius)
    {
        if (x >= radius && x <= width - radius) return true;
        if (y >= radius && y <= height - radius) return true;

        int cx = x < radius ? radius : width - radius;
        int cy = y < radius ? radius : height - radius;
        float dist = Mathf.Sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
        return dist <= radius;
    }
}
#endif
