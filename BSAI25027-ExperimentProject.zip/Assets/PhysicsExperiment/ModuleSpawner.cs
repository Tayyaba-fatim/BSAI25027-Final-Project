using UnityEngine;

/// <summary>
/// Instantiates a module's world prefab into the scene when chosen from the tray.
/// Attach to an empty GameObject in the scene (e.g. "Spawner").
/// </summary>
public class ModuleSpawner : MonoBehaviour
{
    [Header("Where new modules appear")]
    [Tooltip("Empty transform positioned just above the table where new modules drop in.")]
    [SerializeField] private Transform spawnPoint;

    [Tooltip("Layer assigned to spawned modules so DraggableObject's raycast can find them.")]
    [SerializeField] private string draggableLayerName = "Draggable";

    public void SpawnModule(ExperimentModule module)
    {
        if (module.worldPrefab == null)
        {
            Debug.LogWarning($"Module '{module.moduleName}' has no worldPrefab assigned.");
            return;
        }

        GameObject instance = Instantiate(module.worldPrefab, spawnPoint.position, spawnPoint.rotation);
        instance.transform.localScale = module.spawnScale;
        instance.name = module.moduleName;

        int layer = LayerMask.NameToLayer(draggableLayerName);
        if (layer != -1)
        {
            SetLayerRecursively(instance, layer);
        }

        // Ensure it has the required components for dragging + physics
        if (instance.GetComponent<Collider>() == null)
        {
            instance.AddComponent<BoxCollider>();
        }

        if (instance.GetComponent<DraggableObject>() == null)
        {
            instance.AddComponent<DraggableObject>();
        }

        Rigidbody rb = instance.GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = instance.AddComponent<Rigidbody>();
        }
        rb.useGravity = true; // so it settles onto the table naturally
    }

    private void SetLayerRecursively(GameObject obj, int layer)
    {
        obj.layer = layer;
        foreach (Transform child in obj.transform)
        {
            SetLayerRecursively(child.gameObject, layer);
        }
    }
}
