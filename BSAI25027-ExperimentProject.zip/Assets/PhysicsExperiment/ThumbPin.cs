using UnityEngine;

/// <summary>
/// ThumbPin.cs
/// When dropped onto a PaperSheet, the pin "sticks" into the paper and locks.
/// Cannot be moved after being stuck. Click the pin head to unstick it.
/// </summary>
public class ThumbPin : MonoBehaviour
{
    [Header("Pin Settings")]
    public Color pinColor = Color.red;
    public Renderer pinHeadRenderer;

    [Header("Stick Settings")]
    [Tooltip("How far the pin sinks into the paper (local Y offset when stuck)")]
    public float sinkDepth = 0.015f;
    [Tooltip("How fast the pin animates into the paper")]
    public float sinkSpeed = 8f;

    [Header("Debug")]
    public bool showDebugLogs = true;

    // State
    private bool isStuck = false;
    private bool isSinking = false;
    private Vector3 targetPosition;
    private DraggableObject draggable;

    private void Awake()
    {
        draggable = GetComponent<DraggableObject>();

        if (pinHeadRenderer == null)
            pinHeadRenderer = GetComponentInChildren<Renderer>();

        if (pinHeadRenderer != null)
        {
            pinHeadRenderer.material = new Material(pinHeadRenderer.material);
            pinHeadRenderer.material.color = pinColor;
        }

        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.isKinematic = true;
            rb.useGravity = false;
        }
    }

    private void Update()
    {
        // Animate pin sinking into paper
        if (isSinking)
        {
            transform.position = Vector3.Lerp(
                transform.position, targetPosition,
                Time.deltaTime * sinkSpeed);

            if (Vector3.Distance(transform.position, targetPosition) < 0.001f)
            {
                transform.position = targetPosition;
                isSinking = false;
            }
        }
    }

    /// <summary>
    /// Called by DraggableObject when the pin is dropped.
    /// Check if dropped on a PaperSheet — if yes, stick it.
    /// </summary>
    public void OnDropped(Vector3 dropPosition)
    {
        if (isStuck) return;

        // Check if there is a PaperSheet under the drop point
        Ray downRay = new Ray(dropPosition + Vector3.up * 0.1f, Vector3.down);
        RaycastHit[] hits = Physics.RaycastAll(downRay, 0.5f);

        if (showDebugLogs)
            Debug.Log($"[ThumbPin] OnDropped at {dropPosition}. Ray hit {hits.Length} colliders.");

        foreach (var h in hits)
        {
            if (showDebugLogs)
                Debug.Log($"[ThumbPin]  -> hit: {h.collider.gameObject.name} | has PaperSheet: {h.collider.GetComponent<PaperSheet>() != null}");

            if (h.collider.GetComponent<PaperSheet>() != null)
            {
                StickIntoPaper(dropPosition);
                return;
            }
        }

        if (showDebugLogs)
            Debug.Log("[ThumbPin] No PaperSheet found under pin. Pin stays draggable.");

        // Not on paper — stays draggable, do nothing
    }

    private void StickIntoPaper(Vector3 position)
    {
        isStuck = true;

        if (showDebugLogs)
            Debug.Log("[ThumbPin] STUCK into paper. Locking drag.");

        // Lock dragging
        if (draggable != null)
            draggable.isLocked = true;

        // Animate pin sinking down slightly
        targetPosition = new Vector3(position.x,
                                     position.y - sinkDepth,
                                     position.z);
        isSinking = true;

        // Change pin color slightly darker to show it's stuck
        if (pinHeadRenderer != null)
        {
            Color stuck = pinColor * 0.75f;
            stuck.a = 1f;
            pinHeadRenderer.material.color = stuck;
        }
    }

    /// <summary>
    /// Call this to unstick the pin (e.g. right-click or UI button).
    /// </summary>
    public void Unstick()
    {
        if (!isStuck) return;
        isStuck = false;

        if (draggable != null)
            draggable.isLocked = false;

        if (pinHeadRenderer != null)
            pinHeadRenderer.material.color = pinColor;
    }

    public bool IsStuck => isStuck;
}