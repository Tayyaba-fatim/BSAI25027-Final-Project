using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// PencilToolUI.cs
/// Attach to any GameObject in the scene.
/// Connect your UI Pencil button and Clear button in the Inspector.
/// This bridges your existing UI system with PencilTool.cs
/// </summary>
public class PencilToolUI : MonoBehaviour
{
    [Header("References")]
    [Tooltip("The PencilTool component in the scene (on Spawner or ToolManager).")]
    public PencilTool pencilTool;

    [Header("UI Buttons")]
    [Tooltip("The toggle button for pencil mode.")]
    public Button pencilToggleButton;
    [Tooltip("Button to clear all drawings.")]
    public Button clearButton;

    [Header("Button Visuals")]
    [Tooltip("Normal color of pencil button.")]
    public Color normalColor = new Color(0.2f, 0.6f, 1f);
    [Tooltip("Active/pressed color when pencil mode is ON.")]
    public Color activeColor = new Color(0.1f, 0.85f, 0.3f);

    private Image pencilButtonImage;

    private void Start()
    {
        if (pencilToggleButton != null)
        {
            pencilButtonImage = pencilToggleButton.GetComponent<Image>();
            pencilToggleButton.onClick.AddListener(OnPencilToggleClicked);
            UpdateButtonVisual();
        }

        if (clearButton != null)
        {
            clearButton.onClick.AddListener(OnClearClicked);
        }
    }

    private void OnPencilToggleClicked()
    {
        if (pencilTool == null) return;
        pencilTool.TogglePencil();
        UpdateButtonVisual();
    }

    private void OnClearClicked()
    {
        if (pencilTool == null) return;
        pencilTool.ClearAllDrawings();
    }

    private void UpdateButtonVisual()
    {
        if (pencilButtonImage == null || pencilTool == null) return;
        pencilButtonImage.color = pencilTool.IsPencilActive ? activeColor : normalColor;
    }
}
