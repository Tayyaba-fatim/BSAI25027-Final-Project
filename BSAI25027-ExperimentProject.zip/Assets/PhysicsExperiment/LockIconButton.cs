using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Sits on the small lock icon spawned above a locked PaperSheet.
/// Clicking it calls PaperSheet.Unlock() on its owner.
/// Works with either the old or new Input System, same pattern as DraggableObject.
/// </summary>
public class LockIconButton : MonoBehaviour
{
    [HideInInspector] public PaperSheet owner;

    private Camera mainCam;

    private void Start()
    {
        mainCam = Camera.main;
    }

    private void Update()
    {
        if (owner == null || mainCam == null) return;

        bool clicked = false;
        Vector2 screenPos = default;

#if ENABLE_INPUT_SYSTEM
        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            clicked = true;
            screenPos = Mouse.current.position.ReadValue();
        }
#else
        if (Input.GetMouseButtonDown(0))
        {
            clicked = true;
            screenPos = Input.mousePosition;
        }
#endif

        if (!clicked) return;

        Ray ray = mainCam.ScreenPointToRay(screenPos);
        if (Physics.Raycast(ray, out RaycastHit hit, 100f))
        {
            if (hit.collider != null && hit.collider.gameObject == gameObject)
            {
                owner.Unlock();
            }
        }
    }
}
