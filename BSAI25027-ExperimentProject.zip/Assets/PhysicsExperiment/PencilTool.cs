using UnityEngine;
using System.Collections.Generic;

public class PencilTool : MonoBehaviour
{
    [Header("Pencil Settings")]
    [SerializeField] private LayerMask drawLayerMask = ~0;
    [SerializeField] private float lineWidth = 0.003f;
    [SerializeField] private Color lineColor = new Color(0.1f, 0.1f, 0.1f, 1f);
    [SerializeField] private float minPointDistance = 0.005f;
    [SerializeField] private float drawHeight = 0.012f;

    [Header("Auto Straighten")]
    [Tooltip("When enabled, every stroke becomes a straight line from start to end point")]
    public bool autoStraighten = true;

    [Header("Material")]
    [SerializeField] private Material lineMaterial;

    [Header("Debug")]
    [SerializeField] private bool showDebugLogs = false;

    public bool IsPencilActive { get; private set; } = false;

    private Camera mainCamera;
    private LineRenderer currentLine;
    private List<Vector3> currentPoints = new List<Vector3>();
    private List<GameObject> allStrokes = new List<GameObject>();
    private bool isDrawing = false;
    private Vector3 strokeStartPoint;

    private void Awake()
    {
        mainCamera = Camera.main;
        if (mainCamera == null)
            mainCamera = FindObjectOfType<Camera>();

        if (lineMaterial == null)
        {
            Shader s = Shader.Find("Unlit/Color")
                    ?? Shader.Find("Universal Render Pipeline/Unlit")
                    ?? Shader.Find("Sprites/Default");
            lineMaterial = new Material(s);
            lineMaterial.color = lineColor;
        }
    }

    private void Update()
    {
        if (!IsPencilActive) return;

        if (Input.GetMouseButtonDown(0)) TryStartStroke();
        else if (Input.GetMouseButton(0) && isDrawing) ContinueStroke();
        else if (Input.GetMouseButtonUp(0) && isDrawing) EndStroke();
    }

    public void TogglePencil()
    {
        IsPencilActive = !IsPencilActive;
        if (!IsPencilActive && isDrawing) EndStroke();
    }

    public void SetPencilActive(bool active)
    {
        IsPencilActive = active;
        if (!active && isDrawing) EndStroke();
    }

    public void ClearAllDrawings()
    {
        foreach (var s in allStrokes)
            if (s != null) Destroy(s);
        allStrokes.Clear();
    }

    private void TryStartStroke()
    {
        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);

        if (showDebugLogs)
        {
            if (Physics.Raycast(ray, out RaycastHit anyHit, 200f))
                Debug.Log($"[Pencil] Hit: {anyHit.collider.name} layer:{LayerMask.LayerToName(anyHit.collider.gameObject.layer)}");
            else
                Debug.Log("[Pencil] Hit nothing");
        }

        if (!Physics.Raycast(ray, out RaycastHit hit, 200f, drawLayerMask)) return;

        Vector3 start = Elevated(hit.point);
        strokeStartPoint = start;

        GameObject strokeGO = new GameObject("PencilStroke");
        allStrokes.Add(strokeGO);

        currentLine = strokeGO.AddComponent<LineRenderer>();
        currentLine.material = lineMaterial;
        currentLine.startColor = lineColor;
        currentLine.endColor = lineColor;
        currentLine.startWidth = lineWidth;
        currentLine.endWidth = lineWidth;
        currentLine.positionCount = 2;
        currentLine.useWorldSpace = true;
        currentLine.numCapVertices = 4;
        currentLine.numCornerVertices = 4;

        currentLine.SetPosition(0, start);
        currentLine.SetPosition(1, start);

        currentPoints.Clear();
        currentPoints.Add(start);

        isDrawing = true;
        LockPaperUnderPoint(start);
    }

    private void ContinueStroke()
    {
        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        if (!Physics.Raycast(ray, out RaycastHit hit, 200f, drawLayerMask)) return;

        Vector3 point = Elevated(hit.point);

        if (autoStraighten)
        {
            // Live preview of straight line
            currentLine.positionCount = 2;
            currentLine.SetPosition(0, strokeStartPoint);
            currentLine.SetPosition(1, point);
        }
        else
        {
            Vector3 last = currentPoints[currentPoints.Count - 1];
            if (Vector3.Distance(point, last) < minPointDistance) return;
            currentPoints.Add(point);
            currentLine.positionCount = currentPoints.Count;
            currentLine.SetPositions(currentPoints.ToArray());
        }
    }

    private void EndStroke()
    {
        if (autoStraighten)
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            Vector3 endPoint = strokeStartPoint;
            if (Physics.Raycast(ray, out RaycastHit hit, 200f, drawLayerMask))
                endPoint = Elevated(hit.point);

            currentLine.positionCount = 2;
            currentLine.SetPosition(0, strokeStartPoint);
            currentLine.SetPosition(1, endPoint);
        }

        isDrawing = false;
        currentLine = null;
        currentPoints.Clear();
    }

    private Vector3 Elevated(Vector3 p) =>
        new Vector3(p.x, p.y + drawHeight, p.z);

    private void LockPaperUnderPoint(Vector3 worldPoint)
    {
        Ray downRay = new Ray(worldPoint + Vector3.up * 0.5f, Vector3.down);
        foreach (var h in Physics.RaycastAll(downRay, 1f))
        {
            PaperSheet ps = h.collider.GetComponent<PaperSheet>();
            if (ps != null) { ps.Lock(); return; }
        }
    }
}