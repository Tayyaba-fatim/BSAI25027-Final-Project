using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Holds the list of all modules to show in the tray.
/// Create via: Assets > Create > Physics Experiment > Module Database
/// Then drag each ExperimentModule asset into the list.
/// </summary>
[CreateAssetMenu(fileName = "ModuleDatabase", menuName = "Physics Experiment/Module Database")]
public class ModuleDatabase : ScriptableObject
{
    public List<ExperimentModule> modules = new List<ExperimentModule>();
}
