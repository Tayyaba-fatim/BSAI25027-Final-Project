using UnityEngine;

/// <summary>
/// STUB - attach this to the Prism prefab itself (or have ModuleSpawner add it
/// automatically like DraggableObject, if you prefer it on every spawned prism).
///
/// This is where the actual experiment logic goes once the prism is on the table:
/// drawing the incident ray, refraction through the prism faces, angle of deviation, etc.
///
/// Fill in once you confirm the exact experiment steps from your reference material
/// (e.g. ray box position, protractor overlay, draggable ray angle control).
/// </summary>
public class PrismOpticsController : MonoBehaviour
{
    [Header("References (assign once experiment logic is built)")]
    [SerializeField] private Transform incidentRaySource;
    [SerializeField] private LineRenderer rayRenderer; // for drawing the light path

    private void OnEnable()
    {
        // Example hook: re-run the optics calculation whenever the prism is moved/dropped.
        // You could call this from DraggableObject via an event instead of polling.
    }

    private void Update()
    {
        // TODO: recalculate refraction angles based on current prism rotation/position
        // and redraw the ray path using rayRenderer.SetPositions(...)
    }
}
