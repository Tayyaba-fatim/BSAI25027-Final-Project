using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// ReadingsTableBuilder.cs
///
/// Attach this to a SINGLE empty GameObject named "ReadingPanel" that is a
/// child of your Canvas. It builds the entire table (header + 5 data rows)
/// purely in code at Awake() � no manual Hierarchy building, no dragging
/// fields into slots, no duplicating rows.
///
/// HOW TO USE:
/// 1. Delete everything currently under your ReadingPanel object (Header,
///    Row1-Row5, etc.) - we don't need any of it anymore.
/// 2. Make sure ReadingPanel itself still has:
///       - RectTransform
///       - Image (background colour, can be Light blue like your existing one)
/// 3. Add Component -> ReadingsTableBuilder (this script)
/// 4. Set ReadingPanel's size in its RectTransform, e.g. Width 480, Height 300
/// 5. Press Play. The table builds itself inside ReadingPanel.
/// 6. Wire ReadingsButton -> OnClick() -> ReadingPanel -> ReadingsTableBuilder.TogglePanel
///
/// Reading values later (for the deviation-calculation feature):
///     builder.TryGetRow(0, out float incidence, out float deviation);
/// </summary>
public class ReadingsTableBuilder : MonoBehaviour
{
    [Header("Table content")]
    public string[] headers = { "No. of\nObs.", "Angle of\nIncidence (i)", "Angle of\nDeviation (D)" };
    public int rowCount = 5;

    [Header("Sizing")]
    public float rowHeight = 36f;
    public float headerHeight = 44f;
    public float col1Width = 70f;   // "No. of Obs" column
    public float fontSize = 16f;
    public float headerFontSize = 15f;

    [Header("Colours")]
    public Color headerBg = new Color(1f, 0.95f, 0.55f);   // yellow like textbook
    public Color rowBgA = new Color(1f, 1f, 1f);            // white
    public Color rowBgB = new Color(0.93f, 0.97f, 1f);      // very light blue
    public Color textColor = new Color(0.15f, 0.1f, 0.05f);
    public Color inputBg = Color.white;

    // Stores references so values can be read later
    private TMP_InputField[] incidenceFields;
    private TMP_InputField[] deviationFields;

    void Awake()
    {
        BuildTable();
    }

    public void BuildTable()
    {
        incidenceFields = new TMP_InputField[rowCount];
        deviationFields = new TMP_InputField[rowCount];

        RectTransform panelRT = GetComponent<RectTransform>();
        float panelWidth = panelRT.rect.width;
        float colWidth = (panelWidth - col1Width) / 2f;

        float yCursor = 0f; // top-down cursor, we position by anchoredPosition with top-left pivot logic

        // ----- HEADER ROW -----
        GameObject headerRow = CreateRow("Header", headerBg, headerHeight, yCursor);
        CreateCell(headerRow.transform, headers[0], col1Width, headerFontSize, true);
        CreateCell(headerRow.transform, headers[1], colWidth, headerFontSize, true);
        CreateCell(headerRow.transform, headers[2], colWidth, headerFontSize, true);
        yCursor += headerHeight;

        // ----- DATA ROWS -----
        for (int i = 0; i < rowCount; i++)
        {
            Color bg = (i % 2 == 0) ? rowBgA : rowBgB;
            GameObject row = CreateRow("Row" + (i + 1), bg, rowHeight, yCursor);

            CreateCell(row.transform, (i + 1).ToString(), col1Width, fontSize, false);
            incidenceFields[i] = CreateInputCell(row.transform, colWidth);
            deviationFields[i] = CreateInputCell(row.transform, colWidth);

            yCursor += rowHeight;
        }

        // Resize panel to fit content height if it has a fixed-size RectTransform
        panelRT.sizeDelta = new Vector2(panelRT.sizeDelta.x, yCursor + 10f);
    }

    GameObject CreateRow(string name, Color bg, float height, float yPos)
    {
        GameObject row = new GameObject(name, typeof(RectTransform));
        row.transform.SetParent(transform, false);

        RectTransform rt = row.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0f, 1f);
        rt.anchorMax = new Vector2(0f, 1f);
        rt.pivot = new Vector2(0f, 1f);
        rt.anchoredPosition = new Vector2(0f, -yPos);
        rt.sizeDelta = new Vector2(GetComponent<RectTransform>().rect.width, height);

        Image img = row.AddComponent<Image>();
        img.color = bg;

        HorizontalLayoutGroup hlg = row.AddComponent<HorizontalLayoutGroup>();
        hlg.childAlignment = TextAnchor.MiddleCenter;
        hlg.childForceExpandWidth = false;
        hlg.childForceExpandHeight = true;
        hlg.spacing = 1f;

        return row;
    }

    void CreateCell(Transform parent, string text, float width, float fSize, bool bold)
    {
        GameObject cell = new GameObject("Cell", typeof(RectTransform));
        cell.transform.SetParent(parent, false);

        LayoutElement le = cell.AddComponent<LayoutElement>();
        le.preferredWidth = width;
        le.minWidth = width;

        TextMeshProUGUI tmp = cell.AddComponent<TextMeshProUGUI>();
        tmp.text = text;
        tmp.fontSize = fSize;
        tmp.color = textColor;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.fontStyle = bold ? FontStyles.Bold : FontStyles.Normal;
        tmp.enableWordWrapping = true;
    }

    TMP_InputField CreateInputCell(Transform parent, float width)
    {
        GameObject cell = new GameObject("InputCell", typeof(RectTransform));
        cell.transform.SetParent(parent, false);

        LayoutElement le = cell.AddComponent<LayoutElement>();
        le.preferredWidth = width;
        le.minWidth = width;

        Image bg = cell.AddComponent<Image>();
        bg.color = inputBg;

        TMP_InputField field = cell.AddComponent<TMP_InputField>();

        // Text area
        GameObject textArea = new GameObject("Text Area", typeof(RectTransform));
        textArea.transform.SetParent(cell.transform, false);
        RectTransform taRT = textArea.GetComponent<RectTransform>();
        taRT.anchorMin = Vector2.zero;
        taRT.anchorMax = Vector2.one;
        taRT.offsetMin = new Vector2(6, 4);
        taRT.offsetMax = new Vector2(-6, -4);
        RectMask2D mask = textArea.AddComponent<RectMask2D>();

        // Placeholder
        GameObject placeholderGO = new GameObject("Placeholder", typeof(RectTransform));
        placeholderGO.transform.SetParent(textArea.transform, false);
        RectTransform phRT = placeholderGO.GetComponent<RectTransform>();
        phRT.anchorMin = Vector2.zero;
        phRT.anchorMax = Vector2.one;
        phRT.offsetMin = Vector2.zero;
        phRT.offsetMax = Vector2.zero;
        TextMeshProUGUI placeholderTMP = placeholderGO.AddComponent<TextMeshProUGUI>();
        placeholderTMP.text = "�";
        placeholderTMP.fontSize = fontSize;
        placeholderTMP.color = new Color(0.5f, 0.5f, 0.5f, 0.6f);
        placeholderTMP.alignment = TextAlignmentOptions.Center;

        // Actual text
        GameObject textGO = new GameObject("Text", typeof(RectTransform));
        textGO.transform.SetParent(textArea.transform, false);
        RectTransform txtRT = textGO.GetComponent<RectTransform>();
        txtRT.anchorMin = Vector2.zero;
        txtRT.anchorMax = Vector2.one;
        txtRT.offsetMin = Vector2.zero;
        txtRT.offsetMax = Vector2.zero;
        TextMeshProUGUI textTMP = textGO.AddComponent<TextMeshProUGUI>();
        textTMP.fontSize = fontSize;
        textTMP.color = textColor;
        textTMP.alignment = TextAlignmentOptions.Center;

        field.textViewport = taRT;
        field.textComponent = textTMP;
        field.placeholder = placeholderTMP;
        field.contentType = TMP_InputField.ContentType.DecimalNumber;

        return field;
    }

    // ---------- Public API ----------

    public void TogglePanel()
    {
        gameObject.SetActive(!gameObject.activeSelf);
    }

    public void ShowPanel() => gameObject.SetActive(true);
    public void HidePanel() => gameObject.SetActive(false);

    public bool TryGetRow(int index, out float incidence, out float deviation)
    {
        incidence = 0f;
        deviation = 0f;
        if (incidenceFields == null || index < 0 || index >= incidenceFields.Length) return false;

        bool a = float.TryParse(incidenceFields[index].text, out incidence);
        bool b = float.TryParse(deviationFields[index].text, out deviation);
        return a && b;
    }

    public void ClearAllRows()
    {
        if (incidenceFields == null) return;
        for (int i = 0; i < incidenceFields.Length; i++)
        {
            incidenceFields[i].text = "";
            deviationFields[i].text = "";
        }
    }
}