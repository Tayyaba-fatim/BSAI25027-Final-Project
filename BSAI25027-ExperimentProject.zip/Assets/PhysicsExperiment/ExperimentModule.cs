using UnityEngine;

/// <summary>
/// Data definition for one draggable physics apparatus (e.g. Prism, Ray Box, Mirror).
/// Create one of these per module via: Assets > Create > Physics Experiment > Module
/// </summary>
[CreateAssetMenu(fileName = "NewModule", menuName = "Physics Experiment/Module")]
public class ExperimentModule : ScriptableObject
{
    [Header("Identity")]
    public string moduleName = "Prism";
    [TextArea] public string description;

    [Header("UI")]
    public Sprite icon;

    [Header("World Object")]
    [Tooltip("The 3D prefab that gets instantiated onto the table when this module is selected.")]
    public GameObject worldPrefab;

    [Header("Placement")]
    [Tooltip("Local scale applied when spawned (in case the imported prefab is too big/small).")]
    public Vector3 spawnScale = Vector3.one;
}
