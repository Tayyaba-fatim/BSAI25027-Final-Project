using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// AngleReadoutButton.cs
/// One button: click it, it grabs the latest angle of incidence and angle
/// of deviation directly from PrismController and displays them on screen.
///
/// Setup (2 things to assign in Inspector, that's it):
///   1. prismController -> drag your Prism GameObject here
///   2. resultLabel     -> drag a TextMeshPro UI Text object here (the one
///                          that will show the result)
/// Then wire a UI Button's OnClick() -> AngleReadoutButton -> MeasureNow()
/// </summary>
public class AngleReadoutButton : MonoBehaviour
{
    [Header("References")]
    [Tooltip("Drag your Prism GameObject (the one with PrismController) here.")]
    public PrismController prismController;
    [Tooltip("A TextMeshProUGUI element that will display the result.")]
    public TextMeshProUGUI resultLabel;

    /// <summary>
    /// Call this from a UI Button's OnClick() event.
    /// </summary>
    public void MeasureNow()
    {
        if (prismController == null)
        {
            SetText("Prism not assigned.");
            return;
        }

        if (!prismController.hasValidReading)
        {
            SetText("Turn on the ray box first (Space), aim it at the prism, then click Measure.");
            return;
        }

        float i = prismController.angleOfIncidence;
        float d = prismController.angleOfDeviation;

        SetText($"Angle of Incidence (i): {i:F1}\u00B0\nAngle of Deviation (D): {d:F1}\u00B0");
    }

    void SetText(string s)
    {
        if (resultLabel != null)
            resultLabel.text = s;
        else
            Debug.Log("[AngleReadoutButton] " + s);
    }
}