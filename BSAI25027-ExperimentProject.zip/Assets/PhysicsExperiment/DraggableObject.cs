using UnityEngine;

/// <summary>
/// Attach to any object that should be click-and-draggable on the table.
/// After release, object snaps flat onto the table surface � no Rigidbody needed.
///
/// LOCK / UNLOCK:
/// Right-click an object to toggle its lock state at any time.
/// While locked, it cannot be picked up or dragged at all (left-click drag is ignored).
/// </summary>
[RequireComponent(typeof(Collider))]
public class DraggableObject : MonoBehaviour
{
    [Header("Drag Settings")]
    [Tooltip("Layer mask for the table surface.")]
    [SerializeField] private LayerMask tableLayerMask;
    [Tooltip("Small gap kept above the table while dragging.")]
    [SerializeField] private float liftHeight = 0.02f;
    [Tooltip("Higher = snappier follow.")]
    [SerializeField] private float dragSmoothing = 25f;

    [Header("Lock")]
    public bool isLocked = false;
    [Tooltip("Allow right-click to toggle lock state on this object at runtime.")]
    public bool allowManualLockToggle = true;

    [Header("Lock Visual Feedback (optional)")]
    [Tooltip("Renderer to tint when locked. Leave empty to skip visual feedback.")]
    [SerializeField] private Renderer lockIndicatorRenderer;
    [SerializeField] private Color lockedTint = new Color(0.8f, 0.8f, 0.8f, 1f);
    private Color originalColor;
    private bool hasOriginalColor = false;

    [Header("Flat Snap Settings")]
    [Tooltip("If true, object rotation is locked flat (X=90 for Quad) on the table after drop.")]
    [SerializeField] private bool snapFlatOnDrop = true;
    [Tooltip("The rotation to apply when snapping flat. For a Quad paper: 90,0,0")]
    [SerializeField] private Vector3 flatRotation = new Vector3(90f, 0f, 0f);

    private Camera mainCamera;
    private bool isDragging = false;
    private Vector3 dragTargetPosition;
    private float tableY = -1f; // cached table surface Y

    private void Awake()
    {
        mainCamera = Camera.main;

        // Remove Rigidbody if present � we don't need physics, we control position directly
        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.isKinematic = true;
            rb.useGravity = false;
        }

        if (lockIndicatorRenderer != null)
        {
            originalColor = lockIndicatorRenderer.material.color;
            hasOriginalColor = true;
        }
    }

    private void Update()
    {
        bool buttonDown = GetMouseButtonDown();
        bool buttonUp = GetMouseButtonUp();
        bool rightClick = GetMouseButtonRightDown();

        // Right-click toggles lock, regardless of current drag state
        if (rightClick && allowManualLockToggle && IsPointerOverThisObject())
        {
            ToggleLock();
        }

        if (!isDragging && buttonDown && !isLocked && IsPointerOverThisObject())
        {
            StartDrag();
        }

        if (isDragging)
        {
            UpdateDragTarget();

            if (buttonUp)
            {
                EndDrag();
            }
        }
    }

    private void FixedUpdate()
    {
        if (!isDragging) return;
        transform.position = Vector3.Lerp(transform.position, dragTargetPosition, dragSmoothing * Time.fixedDeltaTime);
    }

    private void StartDrag()
    {
        if (isLocked) return;
        isDragging = true;
        tableY = -1f; // reset cached Y
    }

    private void EndDrag()
    {
        isDragging = false;

        // Snap flat onto table surface
        if (snapFlatOnDrop)
        {
            transform.rotation = Quaternion.Euler(flatRotation);

            // Pin Y exactly to table surface
            if (tableY > -1f)
            {
                transform.position = new Vector3(
                    transform.position.x,
                    tableY + liftHeight,
                    transform.position.z
                );
            }
        }

        ThumbPin pin = GetComponent<ThumbPin>();
        if (pin != null)
            pin.OnDropped(transform.position);
    }

    private void UpdateDragTarget()
    {
        Ray ray = mainCamera.ScreenPointToRay(GetMousePosition());

        if (Physics.Raycast(ray, out RaycastHit hit, 200f, tableLayerMask))
        {
            // Cache the table Y so we can snap to it on drop
            tableY = hit.point.y;
            dragTargetPosition = new Vector3(hit.point.x, tableY + liftHeight, hit.point.z);
        }
        else
        {
            // Fallback: keep same Y, move in XZ
            Plane fallbackPlane = new Plane(Vector3.up, transform.position);
            if (fallbackPlane.Raycast(ray, out float distance))
            {
                Vector3 p = ray.GetPoint(distance);
                dragTargetPosition = new Vector3(p.x, transform.position.y, p.z);
            }
        }
    }

    private bool IsPointerOverThisObject()
    {
        Ray ray = mainCamera.ScreenPointToRay(GetMousePosition());
        if (Physics.Raycast(ray, out RaycastHit hit, 500f))
        {
            return hit.collider != null && hit.collider.gameObject == gameObject;
        }
        return false;
    }

    // ---- Lock control ----

    public void ToggleLock()
    {
        isLocked = !isLocked;
        ApplyLockVisual();

        if (isLocked)
            isDragging = false; // stop any in-progress drag immediately
    }

    public void SetLocked(bool locked)
    {
        isLocked = locked;
        if (isLocked) isDragging = false;
        ApplyLockVisual();
    }

    private void ApplyLockVisual()
    {
        if (lockIndicatorRenderer == null || !hasOriginalColor) return;
        lockIndicatorRenderer.material.color = isLocked ? lockedTint : originalColor;
    }

    // ---- Input abstraction ----

    private Vector2 GetMousePosition()
    {
#if ENABLE_INPUT_SYSTEM
        if (UnityEngine.InputSystem.Mouse.current != null)
            return UnityEngine.InputSystem.Mouse.current.position.ReadValue();
        return Vector2.zero;
#else
        return Input.mousePosition;
#endif
    }

    private bool GetMouseButtonDown()
    {
#if ENABLE_INPUT_SYSTEM
        if (UnityEngine.InputSystem.Mouse.current != null)
            return UnityEngine.InputSystem.Mouse.current.leftButton.wasPressedThisFrame;
        return false;
#else
        return Input.GetMouseButtonDown(0);
#endif
    }

    private bool GetMouseButtonUp()
    {
#if ENABLE_INPUT_SYSTEM
        if (UnityEngine.InputSystem.Mouse.current != null)
            return UnityEngine.InputSystem.Mouse.current.leftButton.wasReleasedThisFrame;
        return false;
#else
        return Input.GetMouseButtonUp(0);
#endif
    }

    private bool GetMouseButtonRightDown()
    {
#if ENABLE_INPUT_SYSTEM
        if (UnityEngine.InputSystem.Mouse.current != null)
            return UnityEngine.InputSystem.Mouse.current.rightButton.wasPressedThisFrame;
        return false;
#else
        return Input.GetMouseButtonDown(1);
#endif
    }
}