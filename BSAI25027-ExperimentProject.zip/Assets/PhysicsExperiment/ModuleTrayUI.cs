using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Controls the slide-out tray of module icons.
/// Attach to a UI Panel GameObject (the tray itself).
/// </summary>
public class ModuleTrayUI : MonoBehaviour
{
    [Header("Setup")]
    [SerializeField] private ModuleDatabase database;
    [SerializeField] private Button toggleButton;       // the single icon that opens/closes the tray
    [SerializeField] private GameObject trayPanel;       // the panel containing module buttons
    [SerializeField] private Transform buttonContainer;  // parent with a HorizontalLayoutGroup/GridLayoutGroup
    [SerializeField] private Button moduleButtonPrefab;  // a Button prefab with an Image + Text child

    [Header("Spawning")]
    [SerializeField] private ModuleSpawner spawner;

    private bool isOpen = false;

    private void Start()
    {
        trayPanel.SetActive(false);
        toggleButton.onClick.AddListener(ToggleTray);
        BuildButtons();
    }

    private void ToggleTray()
    {
        isOpen = !isOpen;
        trayPanel.SetActive(isOpen);
    }

    private void BuildButtons()
    {
        foreach (Transform child in buttonContainer)
        {
            Destroy(child.gameObject);
        }

        foreach (ExperimentModule module in database.modules)
        {
            Button btn = Instantiate(moduleButtonPrefab, buttonContainer);
            btn.image.sprite = module.icon;

            // If your button prefab has a child Text/TMP label, grab and set it (optional)
            Text label = btn.GetComponentInChildren<Text>();
            if (label != null) label.text = module.moduleName;

            ExperimentModule capturedModule = module; // local copy for closure safety
            btn.onClick.AddListener(() =>
            {
                spawner.SpawnModule(capturedModule);
                // Optional: close tray after picking a module
                isOpen = false;
                trayPanel.SetActive(false);
            });
        }
    }
}
