using UnityEngine;
using System.Collections;

/// <summary>
/// Smoothly switches the Main Camera between its normal perspective view
/// and a straight-down orthographic "top view" over the table — useful for
/// measuring angles accurately (no perspective distortion) while marking
/// incident/refraction angles on paper under the prism/raybox.
///
/// Attach this to any persistent object in the scene (e.g. the Main Camera
/// itself, or an empty "CameraController" object).
/// </summary>
public class TopViewCameraController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Camera targetCamera;
    [SerializeField] private Transform tableCenter; // empty transform positioned at the table's center, at tabletop height

    [Header("Top View Settings")]
    [SerializeField] private float topViewHeight = 3f;       // how far above the table the camera sits when in top view
    [SerializeField] private float topViewOrthoSize = 1.5f;  // zoom level in top view (smaller = more zoomed in)

    [Header("Transition")]
    [SerializeField] private float transitionDuration = 0.6f;
    [SerializeField] private AnimationCurve easeCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);

    private Vector3 normalPosition;
    private Quaternion normalRotation;
    private bool normalWasOrthographic;
    private float normalOrthoSize;
    private float normalFieldOfView;

    private bool isInTopView = false;
    private bool isTransitioning = false;
    private Coroutine activeTransition;

    private void Awake()
    {
        if (targetCamera == null)
        {
            targetCamera = Camera.main;
        }

        // Remember the camera's original (normal) view so we can return to it exactly.
        normalPosition = targetCamera.transform.position;
        normalRotation = targetCamera.transform.rotation;
        normalWasOrthographic = targetCamera.orthographic;
        normalOrthoSize = targetCamera.orthographicSize;
        normalFieldOfView = targetCamera.fieldOfView;
    }

    /// <summary>Call this from the "Top View" button.</summary>
    public void SwitchToTopView()
    {
        if (isInTopView || isTransitioning) return;

        Vector3 targetPos = (tableCenter != null ? tableCenter.position : Vector3.zero) + Vector3.up * topViewHeight;
        Quaternion targetRot = Quaternion.Euler(90f, 0f, 0f); // straight down

        if (activeTransition != null) StopCoroutine(activeTransition);
        activeTransition = StartCoroutine(AnimateCamera(targetPos, targetRot, true, topViewOrthoSize, () =>
        {
            isInTopView = true;
        }));
    }

    /// <summary>Call this from the "Normal View" / "Back" button.</summary>
    public void SwitchToNormalView()
    {
        if (!isInTopView || isTransitioning) return;

        if (activeTransition != null) StopCoroutine(activeTransition);
        activeTransition = StartCoroutine(AnimateCamera(normalPosition, normalRotation, normalWasOrthographic,
            normalWasOrthographic ? normalOrthoSize : normalFieldOfView, () =>
        {
            isInTopView = false;
        }));
    }

    private IEnumerator AnimateCamera(Vector3 targetPos, Quaternion targetRot, bool useOrthographic, float targetSizeOrFov, System.Action onComplete)
    {
        isTransitioning = true;

        Vector3 startPos = targetCamera.transform.position;
        Quaternion startRot = targetCamera.transform.rotation;
        bool startOrthographic = targetCamera.orthographic;
        float startOrthoSize = targetCamera.orthographicSize;
        float startFov = targetCamera.fieldOfView;

        // Switching projection type (perspective <-> orthographic) can't be
        // smoothly blended natively, so we snap to orthographic immediately
        // when heading INTO top view (the FOV/size morph still feels smooth
        // because position+rotation are animating into place at the same time),
        // and snap back to perspective only at the very end when returning.
        if (useOrthographic && !startOrthographic)
        {
            targetCamera.orthographic = true;
            targetCamera.orthographicSize = startFov; // rough starting size, corrected below as it animates
        }

        float elapsed = 0f;
        while (elapsed < transitionDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / transitionDuration);
            float eased = easeCurve.Evaluate(t);

            targetCamera.transform.position = Vector3.Lerp(startPos, targetPos, eased);
            targetCamera.transform.rotation = Quaternion.Slerp(startRot, targetRot, eased);

            if (useOrthographic)
            {
                targetCamera.orthographicSize = Mathf.Lerp(
                    startOrthographic ? startOrthoSize : 5f, // fallback starting size if coming from perspective
                    targetSizeOrFov,
                    eased
                );
            }
            else if (!startOrthographic)
            {
                targetCamera.fieldOfView = Mathf.Lerp(startFov, targetSizeOrFov, eased);
            }

            yield return null;
        }

        targetCamera.transform.position = targetPos;
        targetCamera.transform.rotation = targetRot;

        if (!useOrthographic)
        {
            targetCamera.orthographic = false;
            targetCamera.fieldOfView = targetSizeOrFov;
        }
        else
        {
            targetCamera.orthographic = true;
            targetCamera.orthographicSize = targetSizeOrFov;
        }

        isTransitioning = false;
        onComplete?.Invoke();
    }
}
