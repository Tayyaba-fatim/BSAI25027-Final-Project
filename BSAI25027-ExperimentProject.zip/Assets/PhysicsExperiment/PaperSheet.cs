using UnityEngine;

/// <summary>
/// Attach to the Paper Sheet prefab. Tracks whether this specific sheet is
/// locked (after the pencil draws on it) and handles the visual dim + the
/// floating lock icon that lets the student unlock it again.
/// </summary>
public class PaperSheet : MonoBehaviour
{
    [Header("Lock Visuals")]
    [Tooltip("The Renderer whose color should dim when locked (usually the paper's own MeshRenderer).")]
    public Renderer paperRenderer;

    [Tooltip("Color the paper tints to when locked.")]
    public Color lockedColor = new Color(0.75f, 0.75f, 0.75f, 1f);

    [Tooltip("Original/unlocked color. Auto-captured at Start if left white.")]
    public Color unlockedColor = Color.white;

    [Header("Lock Icon")]
    [Tooltip("World-space prefab (a small canvas/sprite) shown above the sheet when locked. Assign LockIconPrefab here.")]
    public GameObject lockIconPrefab;

    [Tooltip("How far above the paper (local Y) the lock icon floats.")]
    public float lockIconHeight = 0.05f;

    public bool IsLocked { get; private set; }

    private GameObject spawnedLockIcon;
    private DraggableObject draggable;

    private void Awake()
    {
        draggable = GetComponent<DraggableObject>();

        if (paperRenderer == null)
            paperRenderer = GetComponent<Renderer>();

        if (paperRenderer != null)
            unlockedColor = paperRenderer.material.color;
    }

    /// <summary>
    /// Called by Pencil.cs the moment a stroke touches this sheet.
    /// Safe to call repeatedly - does nothing if already locked.
    /// </summary>
    public void Lock()
    {
        if (IsLocked) return;
        IsLocked = true;

        if (draggable != null)
            draggable.isLocked = true;

        if (paperRenderer != null)
            paperRenderer.material.color = lockedColor;

        SpawnLockIcon();
    }

    /// <summary>
    /// Called when the student clicks the floating lock icon.
    /// </summary>
    public void Unlock()
    {
        if (!IsLocked) return;
        IsLocked = false;

        if (draggable != null)
            draggable.isLocked = false;

        if (paperRenderer != null)
            paperRenderer.material.color = unlockedColor;

        if (spawnedLockIcon != null)
        {
            Destroy(spawnedLockIcon);
            spawnedLockIcon = null;
        }
    }

    private void SpawnLockIcon()
    {
        if (lockIconPrefab == null || spawnedLockIcon != null) return;

        spawnedLockIcon = Instantiate(lockIconPrefab, transform);
        spawnedLockIcon.transform.localPosition = new Vector3(0f, lockIconHeight, 0f);
        spawnedLockIcon.transform.localRotation = Quaternion.identity;

        LockIconButton btn = spawnedLockIcon.GetComponent<LockIconButton>();
        if (btn == null)
            btn = spawnedLockIcon.AddComponent<LockIconButton>();
        btn.owner = this;
    }

    private void OnDestroy()
    {
        if (spawnedLockIcon != null)
            Destroy(spawnedLockIcon);
    }
}
