using System;
using System.Collections.Generic;
using UnityEngine;


namespace Optics
{

    [Serializable]
    public struct LightRay
    {
        [Range(380f, 780f)] public float wavelengthNm;
        public Color color;

        public static LightRay[] WhiteLight() => new LightRay[]
        {
            new LightRay { wavelengthNm = 405f, color = new Color(0.58f, 0.00f, 0.83f) },
            new LightRay { wavelengthNm = 450f, color = new Color(0.00f, 0.00f, 1.00f) },
            new LightRay { wavelengthNm = 490f, color = new Color(0.00f, 0.60f, 1.00f) },
            new LightRay { wavelengthNm = 530f, color = new Color(0.00f, 0.80f, 0.00f) },
            new LightRay { wavelengthNm = 580f, color = new Color(1.00f, 1.00f, 0.00f) },
            new LightRay { wavelengthNm = 620f, color = new Color(1.00f, 0.50f, 0.00f) },
            new LightRay { wavelengthNm = 680f, color = new Color(1.00f, 0.00f, 0.00f) },
        };
    }

    public struct PrismTraceResult
    {
        public float wavelengthNm;
        public Color color;
        public float incidenceAngleDeg;
        public float refractionAngle1Deg;
        public float internalAngle2Deg;
        public float emergenceAngleDeg;
        public float deviationAngleDeg;
        public float refractiveIndex;
        public bool totalInternalReflection;
        public Vector3[] pathPoints;
    }

    public enum PrismMaterial { CrownGlass, FlintGlass, Quartz, Diamond, AcrylicPlastic, Custom }

    [Serializable]
    public struct CauchyCoefficients
    {
        public float A, B, C;

        public float IndexAt(float wavelengthNm)
        {
            float lum = wavelengthNm * 1e-3f;
            return A + B / (lum * lum) + C / (lum * lum * lum * lum);
        }

        public static CauchyCoefficients For(PrismMaterial mat) => mat switch
        {
            PrismMaterial.CrownGlass => new CauchyCoefficients { A = 1.5220f, B = 0.00459f },
            PrismMaterial.FlintGlass => new CauchyCoefficients { A = 1.6200f, B = 0.01080f },
            PrismMaterial.Quartz => new CauchyCoefficients { A = 1.4580f, B = 0.00354f },
            PrismMaterial.Diamond => new CauchyCoefficients { A = 2.3780f, B = 0.01306f },
            PrismMaterial.AcrylicPlastic => new CauchyCoefficients { A = 1.4870f, B = 0.00483f },
            _ => new CauchyCoefficients { A = 1.5f, B = 0.005f },
        };
    }

    [AddComponentMenu("Optics/Prism Module")]
    public class PrismModule : MonoBehaviour
    {
        [Header("Prism Geometry")]
        [Range(10f, 85f)] public float apexAngleDeg = 60f;
        [Min(0.01f)] public float height = 1f;
        [Min(0.01f)] public float depth = 0.5f;

        [Header("Material")]
        public PrismMaterial material = PrismMaterial.CrownGlass;
        public CauchyCoefficients customCoefficients = CauchyCoefficients.For(PrismMaterial.CrownGlass);

        [Header("Incident Ray")]
        [Range(0f, 89f)] public float incidenceAngleDeg = 35f;
        [Range(0f, 1f)] public float rayHeightFraction = 0.45f;
        [Min(0.1f)] public float rayDisplayLength = 2f;

        [Header("Dispersion")]
        public bool showDispersion = true;
        public LightRay[] customRays;

        [Header("Gizmo Options")]
        public bool drawPrismOutline = true;
        public bool drawRays = true;
        public Color prismGizmoColor = new Color(0.4f, 0.8f, 1f, 0.3f);

        // ── Public API ────────────────────────────────────────────────────────

        public float RefractiveIndex(float wavelengthNm)
        {
            var c = material == PrismMaterial.Custom
                ? customCoefficients
                : CauchyCoefficients.For(material);
            return c.IndexAt(wavelengthNm);
        }

        public float MinimumDeviationAngle(float wavelengthNm)
        {
            float n = RefractiveIndex(wavelengthNm);
            float arg = n * Mathf.Sin(apexAngleDeg * 0.5f * Mathf.Deg2Rad);
            if (arg > 1f) return float.NaN;
            return 2f * Mathf.Asin(arg) * Mathf.Rad2Deg - apexAngleDeg;
        }

        public float CriticalAngle(float wavelengthNm)
        {
            return Mathf.Asin(1f / RefractiveIndex(wavelengthNm)) * Mathf.Rad2Deg;
        }

        public PrismTraceResult? Trace(float wavelengthNm, Color rayColor, float incidenceDeg = -1f)
        {
            float i1 = incidenceDeg < 0 ? incidenceAngleDeg : incidenceDeg;
            float n = RefractiveIndex(wavelengthNm);
            float A = apexAngleDeg;

            float sinR1 = Mathf.Sin(i1 * Mathf.Deg2Rad) / n;
            if (Mathf.Abs(sinR1) > 1f) return null;
            float r1 = Mathf.Asin(sinR1) * Mathf.Rad2Deg;
            float r2 = A - r1;

            bool tir = false;
            float e2 = 0f;
            float dev = 0f;

            float sinE2 = n * Mathf.Sin(r2 * Mathf.Deg2Rad);
            if (Mathf.Abs(sinE2) >= 1f)
                tir = true;
            else
            {
                e2 = Mathf.Asin(sinE2) * Mathf.Rad2Deg;
                dev = i1 + e2 - A;
            }

            var pts = BuildPathPoints(i1, r1, r2, e2, tir);

            return new PrismTraceResult
            {
                wavelengthNm = wavelengthNm,
                color = rayColor,
                incidenceAngleDeg = i1,
                refractionAngle1Deg = r1,
                internalAngle2Deg = r2,
                emergenceAngleDeg = e2,
                deviationAngleDeg = dev,
                refractiveIndex = n,
                totalInternalReflection = tir,
                pathPoints = pts,
            };
        }

        public List<PrismTraceResult> TraceAll()
        {
            var rays = ActiveRays();
            var results = new List<PrismTraceResult>(rays.Length);
            foreach (var ray in rays)
            {
                var r = Trace(ray.wavelengthNm, ray.color);
                if (r.HasValue) results.Add(r.Value);
            }
            return results;
        }

        public static string Summarise(PrismTraceResult r)
        {
            if (r.totalInternalReflection)
                return $"λ={r.wavelengthNm:F0} nm | n={r.refractiveIndex:F4} | TIR";
            return $"λ={r.wavelengthNm:F0} nm | n={r.refractiveIndex:F4} | " +
                   $"i={r.incidenceAngleDeg:F2}° r₁={r.refractionAngle1Deg:F2}° " +
                   $"r₂={r.internalAngle2Deg:F2}° e={r.emergenceAngleDeg:F2}° δ={r.deviationAngleDeg:F2}°";
        }

        // ── Geometry ──────────────────────────────────────────────────────────

        /// <summary>
        /// Cross-section vertices in local XY space.
        /// [0] = apex (top-centre), [1] = base-left, [2] = base-right
        /// The LEFT face (apex→base-left) is the ENTRY face.
        /// </summary>
        public Vector2[] LocalVertices2D()
        {
            float halfBase = height * Mathf.Tan(apexAngleDeg * 0.5f * Mathf.Deg2Rad);
            return new Vector2[]
            {
                new Vector2(0f,         height * 0.5f),
                new Vector2(-halfBase, -height * 0.5f),
                new Vector2( halfBase, -height * 0.5f),
            };
        }

        public Vector3[] WorldVertices()
        {
            var v2 = LocalVertices2D();
            var out_ = new Vector3[v2.Length];
            for (int i = 0; i < v2.Length; i++)
                out_[i] = transform.TransformPoint(new Vector3(v2[i].x, v2[i].y, 0f));
            return out_;
        }

        // ── Internal helpers ──────────────────────────────────────────────────

        private LightRay[] ActiveRays() =>
            (!showDispersion && customRays != null && customRays.Length > 0)
                ? customRays
                : LightRay.WhiteLight();

        /// <summary>
        /// Builds the 4 world-space path points for one ray.
        ///
        /// Coordinate convention (local XY, Z=0 slice):
        ///   - Prism apex points UP (+Y).
        ///   - LEFT face  (apex → base-left)  = entry face.
        ///   - RIGHT face (base-right → apex) = exit face.
        ///   - Incoming ray travels from the LEFT, hitting the left face.
        ///
        /// Angle sign convention:
        ///   - The inward normal of the left face points to the RIGHT (+X side).
        ///   - Positive incidence angle tilts the incoming ray UPWARD from that normal.
        ///   - Positive refraction angle tilts the internal ray DOWNWARD inside the prism.
        ///
        /// Points returned:
        ///   [0] incoming ray start  (outside, before entry)
        ///   [1] entry point         (on left face)
        ///   [2] exit point          (on right face)
        ///   [3] outgoing ray end    (outside, after exit)
        /// </summary>
        private Vector3[] BuildPathPoints(float i1, float r1, float r2, float e2, bool tir)
        {
            var verts = LocalVertices2D();
            Vector2 apex = verts[0];
            Vector2 baseL = verts[1];
            Vector2 baseR = verts[2];

            // ── Left (entry) face ─────────────────────────────────────────────
            // Direction along the face from apex → base-left
            Vector2 leftFaceDir = (baseL - apex).normalized;

            // Inward normal = rotate leftFaceDir 90° CW → points into the prism (+X side)
            Vector2 inNormal1 = new Vector2(leftFaceDir.y, -leftFaceDir.x);
            // Guarantee it truly points inward (positive X)
            if (inNormal1.x < 0f) inNormal1 = -inNormal1;

            // Entry point on the left face
            Vector2 entry = apex + leftFaceDir * (apex - baseL).magnitude * rayHeightFraction;

            // Incoming ray direction: starts from the left, tilted by i1 above the normal.
            // The incoming ray travels RIGHTWARD and hits the face, so its direction
            // has a positive X component. We rotate the inward normal by +i1 upward (CCW).
            Vector2 incomingDir = Rotate2D(inNormal1, i1);   // ray travels in this direction

            // ── Internal ray direction ────────────────────────────────────────
            // Inside the prism: refracted by r1 on the other side of the normal.
            // Rotate inward normal by -r1 (downward, CW) to get the internal travel direction.
            Vector2 internalDir = Rotate2D(inNormal1, -r1);

            // ── Right (exit) face ─────────────────────────────────────────────
            Vector2 rightFaceDir = (apex - baseR).normalized;   // base-right → apex

            // Outward normal of right face: rotate rightFaceDir 90° CW → points outward (+X)
            Vector2 outNormal2 = new Vector2(rightFaceDir.y, -rightFaceDir.x);
            if (outNormal2.x < 0f) outNormal2 = -outNormal2;

            // Inward normal of right face (into prism, -X direction)
            Vector2 inNormal2 = -outNormal2;

            // Find where the internal ray intersects the right face
            Vector2 rightFaceVec = apex - baseR;
            float t2 = RaySegIntersect(entry, internalDir, baseR, rightFaceVec);
            Vector2 exit2D = entry + internalDir * t2;

            // ── Outgoing ray direction ────────────────────────────────────────
            Vector2 outDir;
            if (tir)
            {
                // Reflect off inward normal of face 2
                float dot = Vector2.Dot(internalDir, inNormal2);
                outDir = internalDir - 2f * dot * inNormal2;
            }
            else
            {
                // Refract out: rotate outward normal by +e2 downward (CW)
                outDir = Rotate2D(outNormal2, -e2);
            }

            // ── World space ───────────────────────────────────────────────────
            Vector3 ToWorld(Vector2 p) =>
                transform.TransformPoint(new Vector3(p.x, p.y, 0f));

            return new Vector3[]
            {
                ToWorld(entry  - incomingDir * rayDisplayLength),  // [0] ray source
                ToWorld(entry),                                    // [1] entry
                ToWorld(exit2D),                                   // [2] exit
                ToWorld(exit2D + outDir * rayDisplayLength),       // [3] ray end
            };
        }

        private static Vector2 Rotate2D(Vector2 v, float angleDeg)
        {
            float rad = angleDeg * Mathf.Deg2Rad;
            float c = Mathf.Cos(rad), s = Mathf.Sin(rad);
            return new Vector2(c * v.x - s * v.y, s * v.x + c * v.y);
        }

        private static float RaySegIntersect(Vector2 ro, Vector2 rd, Vector2 so, Vector2 sd)
        {
            float denom = rd.x * sd.y - rd.y * sd.x;
            if (Mathf.Abs(denom) < 1e-8f) return 1f;
            float t = ((so.x - ro.x) * sd.y - (so.y - ro.y) * sd.x) / denom;
            return Mathf.Max(0f, t);
        }

        // ── Gizmos ────────────────────────────────────────────────────────────

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (drawPrismOutline) DrawPrismGizmo();
            if (drawRays) DrawRayGizmos();
        }

        private void DrawPrismGizmo()
        {
            var w = WorldVertices();
            Vector3 dz = transform.TransformDirection(Vector3.forward) * depth;

            Gizmos.color = prismGizmoColor;
            Gizmos.DrawLine(w[0], w[1]);
            Gizmos.DrawLine(w[1], w[2]);
            Gizmos.DrawLine(w[2], w[0]);

            Gizmos.DrawLine(w[0] + dz, w[1] + dz);
            Gizmos.DrawLine(w[1] + dz, w[2] + dz);
            Gizmos.DrawLine(w[2] + dz, w[0] + dz);

            Gizmos.color = new Color(prismGizmoColor.r, prismGizmoColor.g, prismGizmoColor.b, 0.6f);
            for (int i = 0; i < 3; i++) Gizmos.DrawLine(w[i], w[i] + dz);
        }

        private void DrawRayGizmos()
        {
            foreach (var r in TraceAll())
            {
                Gizmos.color = r.color;
                var p = r.pathPoints;
                if (p == null || p.Length < 4) continue;
                Gizmos.DrawLine(p[0], p[1]);
                Gizmos.DrawLine(p[1], p[2]);
                if (!r.totalInternalReflection)
                    Gizmos.DrawLine(p[2], p[3]);
            }
        }
#endif
    }
}