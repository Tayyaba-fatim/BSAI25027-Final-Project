using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Optics
{
    /// <summary>
    /// Generates a real 3D triangular prism mesh that auto-syncs with PrismModule.
    /// Automatically detects Built-in RP / URP / HDRP and picks the right shader.
    /// </summary>
    [RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
    [AddComponentMenu("Optics/Prism Mesh")]
    [ExecuteAlways]
    public class PrismMesh : MonoBehaviour
    {
        [Header("Glass Material")]
        [Tooltip("Assign your own glass material here. Leave empty to auto-generate one.")]
        public Material glassMaterial;

        [Header("Auto-sync with PrismModule")]
        public bool syncWithPrismModule = true;

        [Header("Standalone Geometry (used when not syncing)")]
        public float apexAngleDeg = 60f;
        public float height = 1f;
        public float depth = 0.5f;

        // cached
        private MeshFilter _mf;
        private MeshRenderer _mr;
        private PrismModule _pm;

        private float _lastApex, _lastH, _lastD;

        // ─────────────────────────────────────────────────────────────────────

        private void OnEnable()
        {
            _mf = GetComponent<MeshFilter>();
            _mr = GetComponent<MeshRenderer>();
            _pm = GetComponent<PrismModule>();
            EnsureMaterial();
            Rebuild();
        }

        private void Update()
        {
            // Cheap dirty-check — no allocation, safe in editor & play mode
            GetGeometry(out float a, out float h, out float d);
            if (!Mathf.Approximately(a, _lastApex) ||
                !Mathf.Approximately(h, _lastH) ||
                !Mathf.Approximately(d, _lastD))
                Rebuild();
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Public
        // ─────────────────────────────────────────────────────────────────────

        public void Rebuild()
        {
            GetGeometry(out float apex, out float h, out float dep);
            _lastApex = apex; _lastH = h; _lastD = dep;
            if (_mf != null) _mf.sharedMesh = BuildMesh(apex, h, dep);
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Mesh
        // ─────────────────────────────────────────────────────────────────────

        private static Mesh BuildMesh(float apexDeg, float height, float depth)
        {
            float halfBase = height * Mathf.Tan(apexDeg * 0.5f * Mathf.Deg2Rad);

            // Cross-section vertices — match PrismModule.LocalVertices2D()
            //   Apex = top-centre, BL = base-left, BR = base-right
            Vector3 A = new Vector3(0f, height * 0.5f, 0f);
            Vector3 BL = new Vector3(-halfBase, -height * 0.5f, 0f);
            Vector3 BR = new Vector3(halfBase, -height * 0.5f, 0f);

            // Back face (depth along +Z so the prism sits symmetrically around Z=0 is optional;
            // here we place front at Z=0 and back at Z=+depth so it's fully visible)
            Vector3 Az = A + Vector3.forward * depth;
            Vector3 BLz = BL + Vector3.forward * depth;
            Vector3 BRz = BR + Vector3.forward * depth;

            // Per-face normals
            Vector3 nFront = Vector3.back;          // front face faces -Z (camera)
            Vector3 nBack = Vector3.forward;
            Vector3 nLeft = FaceNormal(BL, A, BLz);  // left slant
            Vector3 nRight = FaceNormal(A, BR, Az);   // right slant
            Vector3 nBottom = Vector3.down;

            // Each face gets its own verts for hard (sharp) edges
            //   0-2   Front tri
            //   3-5   Back  tri
            //   6-9   Left  quad
            //  10-13  Right quad
            //  14-17  Bottom quad
            Vector3[] verts = {
                A,   BL,  BR,          // front
                Az,  BRz, BLz,         // back  (winding flipped)
                BL,  A,   Az,  BLz,    // left  quad
                A,   BR,  BRz, Az,     // right quad
                BL,  BLz, BRz, BR,     // bottom quad
            };

            Vector3[] normals = {
                nFront,  nFront,  nFront,
                nBack,   nBack,   nBack,
                nLeft,   nLeft,   nLeft,   nLeft,
                nRight,  nRight,  nRight,  nRight,
                nBottom, nBottom, nBottom, nBottom,
            };

            Vector2[] uvs = {
                new Vector2(.5f,1), new Vector2(0,0), new Vector2(1,0),
                new Vector2(.5f,1), new Vector2(0,0), new Vector2(1,0),
                new Vector2(0,1), new Vector2(1,1), new Vector2(1,0), new Vector2(0,0),
                new Vector2(0,1), new Vector2(1,1), new Vector2(1,0), new Vector2(0,0),
                new Vector2(0,1), new Vector2(1,1), new Vector2(1,0), new Vector2(0,0),
            };

            int[] tris = {
                0,1,2,          // front
                3,4,5,          // back
                6,7,8,  6,8,9, // left
                10,11,12, 10,12,13, // right
                14,15,16, 14,16,17, // bottom
            };

            var mesh = new Mesh { name = "TriangularPrism" };
            mesh.vertices = verts;
            mesh.normals = normals;
            mesh.uv = uvs;
            mesh.triangles = tris;
            mesh.RecalculateBounds();
            return mesh;
        }

        private static Vector3 FaceNormal(Vector3 p0, Vector3 p1, Vector3 p2)
            => Vector3.Cross(p1 - p0, p2 - p0).normalized;

        // ─────────────────────────────────────────────────────────────────────
        //  Material — auto-detects render pipeline
        // ─────────────────────────────────────────────────────────────────────

        private void EnsureMaterial()
        {
            if (_mr == null) return;
            if (glassMaterial != null) { _mr.sharedMaterial = glassMaterial; return; }

            glassMaterial = CreateGlassMaterial();
            _mr.sharedMaterial = glassMaterial;
        }

        private static Material CreateGlassMaterial()
        {
            // Try URP first, then HDRP, then Built-in
            Shader shader = null;

            shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null)
                shader = Shader.Find("HDRP/Lit");
            if (shader == null)
                shader = Shader.Find("Standard");
            if (shader == null)
                shader = Shader.Find("Diffuse"); // last resort

            var mat = new Material(shader) { name = "PrismGlass_Auto" };

            bool isUrp = shader.name.Contains("Universal");
            bool isHdrp = shader.name.Contains("HDRP");

            if (isUrp)
            {
                // URP transparent setup
                mat.SetFloat("_Surface", 1f);   // 1 = Transparent
                mat.SetFloat("_Blend", 0f);   // Alpha
                mat.SetFloat("_AlphaClip", 0f);
                mat.SetFloat("_ZWrite", 0f);
                mat.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
                mat.renderQueue = 3000;
                mat.color = new Color(0.7f, 0.88f, 1f, 0.22f);
                mat.SetFloat("_Smoothness", 0.95f);
            }
            else if (isHdrp)
            {
                mat.SetFloat("_SurfaceType", 1f); // Transparent
                mat.SetFloat("_BlendMode", 0f); // Alpha
                mat.SetFloat("_ZWrite", 0f);
                mat.color = new Color(0.7f, 0.88f, 1f, 0.22f);
                mat.SetFloat("_Smoothness", 0.95f);
                mat.renderQueue = 3000;
            }
            else
            {
                // Built-in Standard — Transparent mode
                mat.SetFloat("_Mode", 3);
                mat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                mat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                mat.SetInt("_ZWrite", 0);
                mat.DisableKeyword("_ALPHATEST_ON");
                mat.DisableKeyword("_ALPHABLEND_ON");
                mat.EnableKeyword("_ALPHAPREMULTIPLY_ON");
                mat.renderQueue = 3000;
                mat.color = new Color(0.7f, 0.88f, 1f, 0.22f);
                mat.SetFloat("_Metallic", 0f);
                mat.SetFloat("_Glossiness", 0.97f);
            }

            return mat;
        }

        // ─────────────────────────────────────────────────────────────────────

        private void GetGeometry(out float apex, out float h, out float dep)
        {
            if (syncWithPrismModule && _pm != null)
            { apex = _pm.apexAngleDeg; h = _pm.height; dep = _pm.depth; }
            else
            { apex = apexAngleDeg; h = height; dep = depth; }
        }
    }
}