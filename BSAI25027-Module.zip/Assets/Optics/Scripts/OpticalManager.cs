using UnityEngine;
using System.Collections.Generic;

public class OpticalManager : MonoBehaviour
{
    public static OpticalManager Instance;

    [Header("Global Settings")]
    public bool showAllRays = true;
    public bool enableGridSnap = false;
    public float globalGridSize = 0.1f;

    private List<OpticalNeedle> allNeedles = new List<OpticalNeedle>();

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    public void RegisterNeedle(OpticalNeedle needle)
    {
        if (!allNeedles.Contains(needle))
            allNeedles.Add(needle);
    }

    public void UnregisterNeedle(OpticalNeedle needle)
    {
        allNeedles.Remove(needle);
    }

    public void ApplyGlobalSettings()
    {
        foreach (var needle in allNeedles)
        {
            if (needle != null)
            {
                needle.drawRay = showAllRays;
                needle.snapToGrid = enableGridSnap;
                needle.gridSize = globalGridSize;
            }
        }
    }

    public void ClearAllNeedles()
    {
        foreach (var needle in allNeedles)
        {
            if (needle != null)
                Destroy(needle.gameObject);
        }
        allNeedles.Clear();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R)) // Press R to toggle all rays
        {
            showAllRays = !showAllRays;
            ApplyGlobalSettings();
        }
    }
}